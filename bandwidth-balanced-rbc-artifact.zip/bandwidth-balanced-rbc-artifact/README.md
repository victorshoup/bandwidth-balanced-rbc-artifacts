# Artifact: fragment allocations for bandwidth-balanced reliable broadcast

This artifact contains the stake distributions, every fragment allocation reported in the paper, a self-contained checker, the paper's allocation procedure Capped Swiper, the computation of the lower bounds in Table 2, and the integer program used to benchmark Capped Swiper.

An allocation is a vector `v` of non-negative integers, one entry per validator in `stakes.json` order, with a reconstruction threshold `k`. Validator *i* holds `v[i]` fragments of a `(V, k)` erasure code, where `V = sum(v)`. It is valid for a stake threshold `theta` when every set of validators with more than `theta*W` of the stake holds at least `k` fragments. The relay-upload costs, in units of the message length, are `max = n*v_max/k` and `avg = V/k`.

## Files

| file | contents | needs |
|---|---|---|
| `stakes.json` | the eight stake distributions, as integer vectors (two exceed 64 bits, so all checks use Python integers) | |
| `allocations.json` | every allocation: `network`, `theta`, `k`, `v`, `label`; benchmark records also give `m`, `found_by` and `detail`. These allocation vectors are unchanged from v40 | |
| `expected.json` | each record's `(max, avg, V)`, with costs to three decimals; MiniCast recovery-record labels, fragment counts and thresholds; the Table 2 lower bounds and their precision metadata; `|F|` and `n` | |
| `verify.py` | checks every record against `expected.json` | standard library |
| `allocate.py` | Capped Swiper, the paper's allocation procedure | standard library (numpy optional) |
| `bound.py` | the lower bound of Table 2 | numpy, scipy |
| `oracle.py` | the exact evaluator `k*(v)`, used by `allocate.py` and `bound.py` (`solve.py` carries its own copy of the same code) | standard library (numpy optional) |
| `solve.py` | the integer program used for the benchmark | pyscipopt |
| `requirements.txt` | the packages above | |
| `allocate_reference.py`, `oracle_reference.py` | the original implementations of `allocate.py` and `oracle.py`, unchanged; `allocate.py` gives the same results, faster, and the tests compare the two | standard library (numpy optional) |
| `tests/` | differential and exhaustive tests of `allocate.py` against `allocate_reference.py`: `python3 tests/run_all.py [--slow]` | standard library (numpy optional) |
| `benchmarks/benchmark.py` | the timings in `PERFORMANCE_OPTIMIZATION_REPORT.md` | standard library (numpy optional) |
| `PERFORMANCE_OPTIMIZATION_REPORT.md` | how `allocate.py` is made fast while staying exact: proofs, tests, timings | |

## Checking everything

```
python3 verify.py
```

No arguments and no dependencies. For every record it recomputes, from `v` alone and in exact integer arithmetic, the largest valid threshold

```
k*(v) = V - max{ v(T) : w(T) <= W - q },   q = floor(theta*W) + 1,
```

checks `k*(v) >= k`, and prints `V`, `v_max`, `max` and `avg`. Costs use the stated `k`. For a `theta = 2/3` record (MiniCast main code), its recovery allocation is the `theta = 1/3` record for the same network, method, band and budget: replace `MiniCast` by `CT` in the label. Both vectors use `stakes.json` order. It reports exact whole-protocol costs, writing `A1 = V1/k1` and `A2 = V2/k2`:

```
max = max_i(n*v_i/k1 + A1*u_i/k2),   avg = A1*(1 + A2/n)
```

Each record is compared with the entry at the same position in `expected.json`: label, network and theta must match, `V` exactly, `max` and `avg` to three decimals. Recovery references, thresholds and fragment counts must also match. For every table, text and benchmark allocation the checker separately enforces its fragment budget and maximum-cost band, including both MiniCast codes. It checks the resulting MiniCast maximum against the same band times the Balanced MiniCast maximum.

It also recomputes `|F|/n`: the fraction of validators belonging to no set of `nu_theta` validators of stake greater than `theta*W`, and the pure 0% lemma bounds described below. Exit status 0 when everything agrees, 1 otherwise with each mismatch listed. The 10% LP bounds in `expected.json` are recomputed by `bound.py`.

## Table 2

One row per network and protocol. Every numeric column is an average cost. Each code separately has at most `4n` fragments. The percentage bounds each allocation's maximum relative to `n/nu_theta`: 0% holds it there (band 1), 10% allows `1.1*n/nu_theta` (band 11/10). For MiniCast this condition applies separately to the main code (`theta = 2/3`) and recovery code (`theta = 1/3`); entries are whole-protocol average costs.

| column | meaning | backed by |
|---|---|---|
| Balanced | one fragment per validator in each code: `n/nu_{1/3}` (CT), `n/nu_{2/3} + n/(nu_{2/3}*nu_{1/3})` (MiniCast) | closed form |
| 0%: Capped Swiper | Capped Swiper with the maximum held at `n/nu_theta` | `table2:CT:4n:band1`, `table2:MiniCast:4n:band1` |
| 0%: Lemma bnd | the pure lower bound from the pinning lemma, described below | `expected.json`, recomputed by `verify.py` |
| 10%: Capped Swiper | Capped Swiper with the maximum within 10% of `n/nu_theta` | `table2:CT:4n`, `table2:MiniCast:4n` |
| 10%: ILP | the best allocation known within 10%, from the integer-programming search | `benchmark:CT:4n`, `benchmark:MiniCast:4n` |
| 10%: LP bnd | lower bound over real-valued shares with the separate 10% allocation caps | `expected.json`, computed by `bound.py` |
| Proportional | proportional virtualization in the limit `V -> infinity` | `3` for CT; `1.5 + 4.5/n` for MiniCast |

For each Capped Swiper or ILP MiniCast entry, use the corresponding CT allocation from the same column as its recovery allocation. Thus the 0% result pairs two band-1 results; the 10% result pairs two band-11/10 results; the ILP result pairs the two benchmark records. This is independent optimization of the two allocation averages under separate constraints. The resulting average is `A1*(1+A2/n)`, which is increasing in both arguments. It does not claim to optimize over all allocation pairs constrained only by a single whole-protocol maximum.

The maximum of each reported MiniCast pair is guaranteed to be at most the stated band times the Balanced MiniCast maximum. Capped Swiper has `A1 <= n/nu_{2/3}`, since the all-ones vector is a candidate; every reported benchmark also satisfies this inequality. Together with `v_max/k1 <= band/nu_{2/3}` and `u_max/k2 <= band/nu_{1/3}`, this bounds every validator's cost by `band*(n/nu_{2/3} + n/(nu_{2/3}*nu_{1/3}))`.

The paper bounds the main-code length `V1` and recovery-code length `V2` separately by `4n`. Each of the `V1` main fragments is encoded into `V2` mini-fragments. A smaller bound on `V2` reduces authentication and per-fragment overhead, potentially at a higher average cost. This artifact's CLI uses the same chosen multiple of `n` for both code lengths. The table has no `V` column; `V` and `V_recovery` are in `expected.json`.

For the pure 0% bound, write `L_theta = (n - |F_theta|)/nu_theta`. The CT bound is `L_{1/3}`; the MiniCast bound is `L_{2/3}*(1+L_{1/3}/n)`. These are the pinning lemma's bounds, without taking their maximum with the 10% LP bound. They may therefore be smaller than the LP bound despite the tighter maximum-cost constraint. Their exact rational values are in `expected.json` under `lemma_bound`; the supporting `free_fraction` data remain included.

## Labels

| label | what it backs |
|---|---|
| `table2:CT:4n` | CT allocation and MiniCast recovery allocation for "10%: Capped Swiper": band 11/10, `V <= 4n` (`theta = 1/3`) |
| `table2:MiniCast:4n` | MiniCast main allocation for "10%: Capped Swiper": band 11/10, `V <= 4n` (`theta = 2/3`) |
| `table2:CT:4n:band1`, `table2:MiniCast:4n:band1` | Table 2, column "0%: Capped Swiper": band 1 (maximum held at `n/nu_theta`), `V <= 4n` |
| `text:CT:2n`, `text:MiniCast:2n` | the text's comparison with `V <= 2n`: Capped Swiper, band 11/10, `V <= 2n` |
| `benchmark:CT:4n`, `benchmark:MiniCast:4n` | Table 2, column "10%: ILP": the best allocation known for each row, band 11/10, `V <= 4n` |
| `frontier:front:n`, `frontier:front:2n`, `frontier:front:4n` | best allocations known for `theta = 1/3` on Monad and Kava with at most `n`, `2n` and `4n` fragments; not plotted in the paper. One record per point |
| `frontier:label` | three individual points of these frontiers (Monad, `V = 380`; Kava, `V = 107` and `V = 54`); not plotted in the paper |

## Capped Swiper: `allocate.py`

Capped Swiper is the paper's allocation procedure. No solver, exact arithmetic, deterministic. For a network, a threshold `theta`, a band on the maximum and a bound `B` on `V`, it scans Swiper's ticket family with a cap,

```
v_i = min(m, floor(s*p_i + c)),   p_i = w_i/W,   c = 1 - theta,
m = 1, ..., floor(band*B/nu_theta),
```

increasing `s` one fragment at a time (validators that reach a breakpoint together are taken in `stakes.json` order) and stopping, for each `m`, at the first `v` with `k*(v) >= 1` and `n*v_max/k* <= band*n/nu_theta`. The candidates are these per-`m` results with `V <= B`, plus one fragment per validator. The winner has the lowest `avg = V/k*`, ties broken by smaller `V`, then smaller `m`. It is then trimmed: validators are visited in increasing stake order and `v_i` is decremented while `k*` does not drop and the band still holds. Larger caps cannot help, since an allocation within the band has `v_max <= band*V/nu_theta`; an uncapped scan was also checked and changes none of the results.

To regenerate every Capped Swiper entry and compare it, allocation included, with `allocations.json`:

```
python3 allocate.py --check --band 11/10 --bound 4 2
python3 allocate.py --check --band 1 --bound 4
```

The first runs the 32 settings behind the `table2:CT:4n`, `table2:MiniCast:4n` and `text:*` records (band 11/10, `V <= 4n` and `V <= 2n`, both thetas, all networks). The second regenerates the band 1 entries of Table 2, `table2:CT:4n:band1` and `table2:MiniCast:4n:band1`, by running `allocate.py` with band 1 and `V <= 4n`. Each result is reported as `reproduces` or `DIFFERS`; exit status 1 on any difference. Other settings:

```
python3 allocate.py Monad --theta 1/3 --band 11/10 --bound 4
python3 allocate.py all --theta 1/3 2/3 --band 1 11/10 --bound 2 4 --json out.json
```

`--bound` is a multiple of `n`, applied separately to both MiniCast codes. For `theta = 2/3` the output gives the whole-protocol cost, the recovery count `V2` and threshold `k2`; JSON output includes both vectors. A MiniCast-only request also computes its matching recovery allocation. Repeated settings are cached, so requesting both thresholds does not repeat a recovery search. The `seconds` column includes any recovery computation needed for that row.

The historical one-thread timing on an Apple M5 of all 64 settings was 27.70 seconds. The paper's 20.10 seconds for Monad and less than three seconds for each other distribution are sums over each network's eight settings (both thresholds, both bands and both budgets), not timings for a single setting. No new optimization is needed for v41: the allocation vectors are unchanged; only the MiniCast pairing and reporting changed.

The implementation of `allocate.py` in this version computes the same allocations faster: all 64 settings take 0.17 s on one core of an AMD Ryzen 9 7950X at a fixed 4.5 GHz with numpy (0.45 s without), against 46.6 s for the original implementation, kept as `allocate_reference.py`, on the same machine. See `PERFORMANCE_OPTIMIZATION_REPORT.md`.

## The lower bound: `bound.py`

```
python3 bound.py
```

For each network and protocol, with `c = (11/10)/nu_theta`, it computes

```
T*(c) = min sum_i y_i   s.t.  y(S) >= 1 for every S with w(S) > theta*W,  0 <= y_i <= c,
```

the least average over real-valued shares whose maximum is within the allocation band. Every allocation within that band gives feasible shares `y = v/k`, so none has a lower average. For MiniCast, let `T1` be the `theta = 2/3` LP value and `T2` the `theta = 1/3` LP value, each at its own cap `c = (11/10)/nu_theta`. The protocol-average lower bound is `T1*(1+T2/n)`. The program computes both LPs even for a MiniCast-only request, and caches repeated settings. This bound covers the separate allocation constraints used in Table 2, for any fragment budgets.

Method: cutting planes. The LP is solved with HiGHS (through scipy) over a growing set of qualifying sets; separation scales the shares to integers and solves the knapsack of `oracle.py` exactly, and every cut is checked in integers, so the LP value is a valid lower bound at every round.

Tolerance: the loop stops when no set with share sum below `1 - 1e-7` is found at resolution `1/200000`. The final shares are then certified independently (every share rounded up, same knapsack), which gives a rigorous `1 - delta` below every constraint; `delta` is printed and is at most `5.1e-4` for the values in `expected.json`, most of it the rounding slack of the certificate itself. The LP works in floating point with HiGHS's default tolerances (`1e-7`). So each printed value is a lower bound on `T*(c)` up to those tolerances, and the shares attaining it meet every constraint to within `delta`. Values are compared with `expected.json` to three decimals. The run takes about 15 minutes on one core, most of it for Monad's CT row.

The v41 expected MiniCast bounds were converted from the original experiment report's raw allocation-LP values, printed to four decimal places. `bound_inputs` preserves those inputs and their half-unit rounding uncertainty (`0.00005`). For every network, both endpoints of the induced product interval round to the same three decimals, which is the value stored in `bound`. Thus the old three-decimal, uniform-recovery protocol costs were not treated as exact inputs. The original numerical solver tolerances still apply; the conversion is not a new LP solve.

## The benchmark: best allocations known

The `benchmark:*` records are the allocations with the lowest average known for each network and threshold (band 11/10, `V <= 4n`); they back the column "10%: ILP". A MiniCast entry pairs the main and recovery benchmark records. These come from a long integer-programming search over code shapes `(k, m)`, in some rows seeded with allocations of the ticket family, and are included to be **verified** by `verify.py`, not regenerated: the search took hours. `found_by` says how each was obtained: `ILP optimal` (an integer-program solve at that `(k, m)` finished with proof of optimality), `ILP time limit` (the best solution a time-limited solve found), or `family`. Fixed-shape optimality does not by itself prove that the search over all shapes finished. The unfinished searches are CT on Sui, and MiniCast on Sui and Osmosis; the corresponding table entries retain their asterisks.

`solve.py` solves the same integer program for one `(k, m)`. Run cold from these files with a 300-second limit, one thread:

| row | network | k | m | V | found_by | solve.py from scratch |
|---|---|---|---|---|---|---|
| CT | Monad | 147 | 7 | 785 | ILP optimal | reproduces (optimal, 2.3 s) |
| CT | Kava | 40 | 22 | 204 | ILP optimal | reproduces (optimal, 0.5 s) |
| CT | Sui | 141 | 8 | 497 | ILP time limit | does not reproduce: timelimit, V = 497 |
| CT | dYdX | 23 | 5 | 98 | ILP optimal | reproduces (optimal, 0.0 s) |
| CT | Sei | 22 | 3 | 86 | ILP optimal | reproduces (optimal, 0.0 s) |
| CT | Osmosis | 32 | 5 | 198 | ILP optimal | reproduces (optimal, 0.0 s) |
| CT | Injective | 51 | 8 | 197 | ILP optimal | reproduces (optimal, 0.3 s) |
| CT | Neutron | 5 | 1 | 13 | ILP optimal | reproduces (optimal, 0.0 s) |
| MiniCast | Monad | 257 | 3 | 465 | ILP optimal | reproduces (optimal, 0.3 s) |
| MiniCast | Kava | 60 | 11 | 212 | ILP optimal | reproduces (optimal, 0.1 s) |
| MiniCast | Sui | 268 | 6 | 456 | ILP optimal | reproduces (optimal, 35.2 s) |
| MiniCast | dYdX | 69 | 5 | 119 | ILP optimal | reproduces (optimal, 0.1 s) |
| MiniCast | Sei | 82 | 5 | 136 | ILP optimal | reproduces (optimal, 0.1 s) |
| MiniCast | Osmosis | 140 | 7 | 253 | ILP optimal | reproduces (optimal, 28.4 s) |
| MiniCast | Injective | 115 | 7 | 198 | ILP optimal | reproduces (optimal, 0.7 s) |
| MiniCast | Neutron | 9 | 1 | 13 | ILP optimal | reproduces (optimal, 0.0 s) |

Of the 16 records tested, 15 are reproduced exactly (the solve finishes optimal with the same `V`).  Records marked `ILP optimal` are optima of this same program at their `(k, m)`; records marked `ILP time limit` were not proved optimal and are not expected to be reproduced exactly.  For example:

```
python3 solve.py Monad 1/3 147 7
```

`solve.py` solves one `(k, m)` from scratch; it has no warm-start option.

## Requirements

`verify.py` and `allocate.py` need only Python 3 (numpy, if installed, makes `allocate.py` faster and changes nothing else). `bound.py` needs numpy and scipy; `solve.py` needs pyscipopt. `pip install -r requirements.txt` installs all three.
