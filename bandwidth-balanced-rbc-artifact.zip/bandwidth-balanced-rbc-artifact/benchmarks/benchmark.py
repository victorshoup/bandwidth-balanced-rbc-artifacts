#!/usr/bin/env python3
"""Timings for PERFORMANCE_OPTIMIZATION_REPORT.md; writes one JSON file.

    python3 benchmarks/benchmark.py --out FILE [--part P ...] [--ref-reps N]

Parts (default: all):
  env        machine and software
  opt        optimized procedure: workloads A (Monad, eight settings), B (the
             Monad MiniCast pair: theta 2/3 and 1/3, band 11/10, 4n, plus
             protocol costs), C (each allocation of B), D (64 settings), and
             every setting of D separately; numpy and pure-Python backends
  shave      shaving only, on the reference's pre-trim vectors: the
             reference loop (exact Oracle.kstar per trial) against trim_fast,
             for the two allocations of B, the pair, and the sum over D
  ablation   cumulative switches of allocate.procedure on B and D
  counts     DP counts: reference (a counting wrapper around Oracle.kstar,
             split into scan and trim) against the optimized counters, D
  ref        reference procedure: A, B, C (--ref-reps runs) and D (one run)
  cold       fresh-process wall clock of the CLI for workload B, against a
             bare interpreter and the imports alone

Every timer is time.perf_counter_ns(); fast workloads are repeated and
reported as median, min, quartiles and mean, in milliseconds.  Run pinned
to one core (taskset) with OMP/OPENBLAS threads at 1.
"""
import json
import os
import platform
import statistics
import subprocess
import sys
import time
from fractions import Fraction as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

import allocate                          # noqa: E402
import allocate_reference as ref         # noqa: E402
import oracle                            # noqa: E402
from oracle import Oracle, TicketOracle, nu   # noqa: E402

STAKES = json.load(open(os.path.join(ROOT, "stakes.json")))
T13, T23, B11 = F(1, 3), F(2, 3), F(11, 10)
SETTINGS = [(net, th, band, mult)
            for th in (T13, T23) for net in allocate.ORDER
            for band in (F(1), B11) for mult in (2, 4)]
MONAD = [s for s in SETTINGS if s[0] == "Monad"]
BACKENDS = ([("numpy", False)] if oracle.np is not None else []) + \
    [("python", True)]


def summary(ns):
    ms = sorted(x / 1e6 for x in ns)
    q = statistics.quantiles(ms, n=4) if len(ms) >= 2 else [ms[0]] * 3
    return dict(reps=len(ms), median_ms=statistics.median(ms), min_ms=ms[0],
                q1_ms=q[0], q3_ms=q[2], iqr_ms=q[2] - q[0],
                mean_ms=statistics.fmean(ms), max_ms=ms[-1])


def timeit(fn, reps, warm=1):
    for _ in range(warm):
        fn()
    out = []
    for _ in range(reps):
        t0 = time.perf_counter_ns()
        fn()
        out.append(time.perf_counter_ns() - t0)
    return summary(out)


def run(proc, s, **kw):
    net, th, band, mult = s
    w = STAKES[net]
    return proc(w, th, band, mult * len(w), **kw)


def pair(proc, prot, **kw):
    w = STAKES["Monad"]
    r = run(proc, ("Monad", T23, B11, 4), **kw)
    rec = run(proc, ("Monad", T13, B11, 4), **kw)
    return prot(w, r, rec)


# ------------------------------------------------------------------ parts
def part_env():
    cpu = "?"
    try:
        for line in open("/proc/cpuinfo"):
            if line.startswith("model name"):
                cpu = line.split(":", 1)[1].strip()
                break
    except OSError:
        pass
    osname = platform.platform()
    try:
        for line in open("/etc/os-release"):
            if line.startswith("PRETTY_NAME="):
                osname = line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    try:
        aff = sorted(os.sched_getaffinity(0))
    except AttributeError:
        aff = None
    return dict(cpu=cpu, os=osname, kernel=platform.release(),
                python=platform.python_version(),
                python_executable=sys.executable,
                numpy=None if oracle.np is None else oracle.np.__version__,
                numpy_active_for_optimized=oracle.np is not None,
                cpu_affinity=aff,
                threads_env={k: os.environ.get(k) for k in
                             ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                              "MKL_NUM_THREADS")},
                note="stakes of dYdX and Injective exceed 2^62, so those "
                     "networks use Python integers in the optimized code "
                     "even when numpy is active")


def part_opt(reps_fast=200, reps_d=30):
    out = {}
    for name, python in BACKENDS:
        kw = dict(python=python)
        d = {}
        d["A_monad_8"] = timeit(
            lambda: [run(allocate.procedure, s, **kw) for s in MONAD],
            max(10, reps_d))
        d["B_pair"] = timeit(lambda: pair(allocate.procedure,
                                          allocate.protocol, **kw), reps_fast)
        d["C_main_2_3"] = timeit(
            lambda: run(allocate.procedure, ("Monad", T23, B11, 4), **kw),
            reps_fast)
        d["C_recovery_1_3"] = timeit(
            lambda: run(allocate.procedure, ("Monad", T13, B11, 4), **kw),
            reps_fast)
        d["D_sweep_64"] = timeit(
            lambda: [run(allocate.procedure, s, **kw) for s in SETTINGS],
            reps_d)
        per = {}
        for s in SETTINGS:
            per["%s %s %s %dn" % (s[0], s[1], s[2], s[3])] = timeit(
                lambda: run(allocate.procedure, s, **kw), 15)["median_ms"]
        d["per_setting_median_ms"] = per
        d["slowest_setting"] = max(per.items(), key=lambda kv: kv[1])
        out[name] = d
        print("  opt[%s]: B %.2f ms, D %.1f ms" % (
            name, d["B_pair"]["median_ms"], d["D_sweep_64"]["median_ms"]),
            flush=True)
    return out


def pretrim(s):
    """The reference's winner (pre-trim vector) and k0, via the optimized
    procedure (equal to the reference's; see tests/test_artifact.py)."""
    st = {}
    run(allocate.procedure, s, stats=st)
    return st["winner"][4], st["winner"][5]


def shave_ref(s, v, k0):
    net, th, band, mult = s
    w = STAKES[net]
    O = Oracle(w, th)
    cache = {tuple(v): k0}                   # the reference has it cached

    def kstar(x):
        t = tuple(x)
        if t not in cache:
            cache[t] = O.kstar(list(x))
        return cache[t]
    return allocate.trim_reference(w, v, nu(w, th), band, kstar)


def shave_opt(s, v, k0, python, st=None):
    net, th, band, mult = s
    w = STAKES[net]
    O = TicketOracle(w, th, python=python)
    opt = dict(allocate.DEFAULT_OPTS)
    nv = nu(w, th)

    def go():
        return allocate.trim_fast(O, v, nv, band, k0, [], opt,
                                  allocate.new_stats() if st is None else st)
    return go


def part_shave(ref_reps=3, reps=300):
    out = {}
    cases = [("main_2_3", ("Monad", T23, B11, 4)),
             ("recovery_1_3", ("Monad", T13, B11, 4))]
    pre = {name: pretrim(s) for name, s in cases}
    for name, s in cases:
        v, k0 = pre[name]
        e = dict(setting="%s %s %s %dn" % s, n=len(v), k0=k0, V_before=sum(v))
        e["reference"] = timeit(lambda: shave_ref(s, v, k0), ref_reps, warm=0)
        for bname, python in BACKENDS:
            st = allocate.new_stats()
            shave_opt(s, v, k0, python, st)()
            e["optimized_" + bname] = timeit(shave_opt(s, v, k0, python),
                                             reps)
            e["optimized_counters"] = {k: st[k] for k in st
                                       if k.startswith("trim_") and
                                       k != "trim_seconds"}
        out[name] = e
        print("  shave %s: ref %.0f ms, opt %.3f ms" % (
            name, e["reference"]["median_ms"],
            e["optimized_" + BACKENDS[0][0]]["median_ms"]), flush=True)
    out["pair"] = dict(
        reference_median_ms=sum(out[n]["reference"]["median_ms"]
                                for n, _ in cases))
    for bname, python in BACKENDS:
        fns = [shave_opt(s, pre[n][0], pre[n][1], python) for n, s in cases]
        out["pair"]["optimized_" + bname] = timeit(
            lambda: [f() for f in fns], reps)
    # every setting of D once (reference) / median (optimized)
    tot_ref, tot_opt, per = 0.0, {b: 0.0 for b, _ in BACKENDS}, []
    for s in SETTINGS:
        v, k0 = pretrim(s)
        t0 = time.perf_counter_ns()
        shave_ref(s, v, k0)
        r = (time.perf_counter_ns() - t0) / 1e6
        tot_ref += r
        row = dict(setting="%s %s %s %dn" % s, reference_ms=r)
        for bname, python in BACKENDS:
            m = timeit(shave_opt(s, v, k0, python), 15)["median_ms"]
            tot_opt[bname] += m
            row["optimized_%s_ms" % bname] = m
        per.append(row)
    out["D_sweep_64"] = dict(reference_total_ms_one_run=tot_ref,
                             optimized_total_of_medians_ms=tot_opt,
                             per_setting=per)
    print("  shave D: ref %.0f ms, opt %s" % (tot_ref, tot_opt), flush=True)
    return out


ABLATION = [
    ("1 prefix skip (cap recursion) only",
     dict(bisect=False, bounded=False, witness=False, shave="reference",
          tight=False)),
    ("2 + suffix bisection",
     dict(bisect=True, bounded=False, witness=False, shave="reference",
          tight=False)),
    ("3 + bounded decision DP",
     dict(bisect=True, bounded=True, witness=False, shave="reference",
          tight=False)),
    ("4 + prefix/suffix shaving (default shave)",
     dict(bisect=True, bounded=True, witness=False, shave="split",
          tight=False)),
    ("5 + witness guards (= production default)",
     dict(bisect=True, bounded=True, witness=True, shave="split",
          tight=False)),
    ("alt: 5 with shave=direct (one forced-inclusion DP per validator)",
     dict(bisect=True, bounded=True, witness=True, shave="direct",
          tight=False)),
    ("alt: 5 with tight='seed'",
     dict(bisect=True, bounded=True, witness=True, shave="split",
          tight="seed")),
    ("alt: 5 with tight=True",
     dict(bisect=True, bounded=True, witness=True, shave="split",
          tight=True)),
]


def part_ablation():
    out = []
    for label, opts in ABLATION:
        slow = opts["shave"] == "reference"
        agg = allocate.new_stats()
        for s in SETTINGS:
            run(allocate.procedure, s, stats=agg, opts=opts)
        e = dict(label=label, opts=opts)
        e["B_pair"] = timeit(lambda: pair(allocate.procedure,
                                          allocate.protocol, opts=opts),
                             5 if slow else 100)
        e["D_sweep_64"] = timeit(
            lambda: [run(allocate.procedure, s, opts=opts) for s in SETTINGS],
            3 if slow else 20, warm=0 if slow else 1)
        e["D_counters"] = {k: agg[k] for k in allocate.STAT_KEYS
                           if k != "trim_seconds"}
        e["D_trim_seconds"] = agg["trim_seconds"]
        out.append(e)
        print("  ablation %-45s B %8.2f ms  D %9.1f ms" % (
            label[:45], e["B_pair"]["median_ms"],
            e["D_sweep_64"]["median_ms"]), flush=True)
    return out


def part_counts():
    """Reference DP counts (distinct k* evaluations = Oracle.kstar calls,
    since the reference caches by state) in scan and trim, D."""
    calls = dict(scan=0, trim=0)
    phase = ["scan"]
    orig_kstar = Oracle.kstar
    orig_trim = ref.trim

    def kstar(self, v):
        calls[phase[0]] += 1
        return orig_kstar(self, v)

    def trim(*a):
        phase[0] = "trim"
        try:
            return orig_trim(*a)
        finally:
            phase[0] = "scan"

    Oracle.kstar = kstar
    ref.trim = trim
    try:
        per = []
        for s in SETTINGS:
            c0 = dict(calls)
            run(ref.procedure, s)
            per.append(dict(setting="%s %s %s %dn" % s,
                            scan=calls["scan"] - c0["scan"],
                            trim=calls["trim"] - c0["trim"]))
    finally:
        Oracle.kstar = orig_kstar
        ref.trim = orig_trim
    agg = allocate.new_stats()
    for s in SETTINGS:
        run(allocate.procedure, s, stats=agg)
    return dict(reference=dict(scan_kstar_dp=calls["scan"],
                               trim_kstar_dp=calls["trim"], per_setting=per),
                optimized={k: agg[k] for k in allocate.STAT_KEYS
                           if k != "trim_seconds"})


def part_ref(reps):
    out = {}
    out["A_monad_8"] = timeit(lambda: [run(ref.procedure, s) for s in MONAD],
                              max(1, reps // 3), warm=0)
    print("  ref A %.0f ms" % out["A_monad_8"]["median_ms"], flush=True)
    out["B_pair"] = timeit(lambda: pair(ref.procedure, ref.protocol), reps,
                           warm=0)
    out["C_main_2_3"] = timeit(
        lambda: run(ref.procedure, ("Monad", T23, B11, 4)), reps, warm=0)
    out["C_recovery_1_3"] = timeit(
        lambda: run(ref.procedure, ("Monad", T13, B11, 4)), reps, warm=0)
    print("  ref B %.0f ms" % out["B_pair"]["median_ms"], flush=True)
    out["D_sweep_64"] = timeit(lambda: [run(ref.procedure, s)
                                        for s in SETTINGS], 1, warm=0)
    print("  ref D %.0f ms" % out["D_sweep_64"]["median_ms"], flush=True)
    return out


def part_cold(reps=30, ref_reps=3):
    py = sys.executable
    argsB = ["Monad", "--theta", "2/3", "--band", "11/10", "--bound", "4"]

    def wall(cmd, n):
        out = []
        for _ in range(n):
            t0 = time.perf_counter_ns()
            subprocess.run(cmd, cwd=ROOT, stdout=subprocess.DEVNULL,
                           check=True)
            out.append(time.perf_counter_ns() - t0)
        return summary(out)

    res = dict(interpreter=py)
    res["bare_interpreter"] = wall([py, "-c", "pass"], reps)
    if oracle.np is not None:
        res["import_numpy"] = wall([py, "-c", "import numpy"], reps)
    res["import_allocate"] = wall([py, "-c", "import allocate"], reps)
    res["optimized_cli_B"] = wall([py, "allocate.py"] + argsB, reps)
    ref_cli = os.path.join(ROOT, "allocate_reference.py")
    res["reference_cli_B"] = wall([py, ref_cli] + argsB, ref_reps)
    return res


def main(argv):
    out_path = argv[argv.index("--out") + 1]
    parts = []
    if "--part" in argv:
        i = argv.index("--part") + 1
        while i < len(argv) and not argv[i].startswith("--"):
            parts.append(argv[i])
            i += 1
    parts = parts or ["env", "opt", "shave", "ablation", "counts", "ref",
                      "cold"]
    ref_reps = int(argv[argv.index("--ref-reps") + 1]) \
        if "--ref-reps" in argv else 3
    res = {}
    if os.path.exists(out_path):
        res = json.load(open(out_path))
    fns = dict(env=part_env, opt=part_opt, shave=part_shave,
               ablation=part_ablation, counts=part_counts,
               ref=lambda: part_ref(ref_reps), cold=part_cold)
    for p in parts:
        print("part", p, flush=True)
        t0 = time.perf_counter()
        res[p] = fns[p]()
        res.setdefault("part_seconds", {})[p] = time.perf_counter() - t0
        res.setdefault("env_by_part", {})[p] = dict(
            python=platform.python_version(),
            numpy=None if oracle.np is None else oracle.np.__version__)
        with open(out_path, "w") as fh:
            json.dump(res, fh, indent=1, default=str)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
