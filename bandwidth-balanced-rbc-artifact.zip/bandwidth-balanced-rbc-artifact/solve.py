#!/usr/bin/env python3
"""Recompute one allocation, from the stake vector alone.

Model, for a fixed reconstruction threshold k and per-validator cap m:

    minimize   V = sum_i v_i
    subject to v(S) >= k   for every S with w(S) > theta*W
               v_i in {0,...,m}
               v_i >= v_j  whenever w_i >= w_j

The coverage rows are exponentially many, so they are generated lazily by a
SCIP constraint handler.  Separation is exact: the most violated row is found
by a 0/1 knapsack over ticket sums,

    k*(v) = V - max{ v(T) : w(T) <= W - q },   q = floor(theta*W) + 1,

and the complement of that T is a qualifying set by construction.  The stake
values never enter the solver, so no tolerance and no large-integer issue can
affect the model; every incumbent is exact and is re-scored by k* before it is
reported.

Dual presolve reductions are switched off.  They argue from the constraints
the solver can see, and most coverage rows are not among them, so such
reductions can remove the true optimum.

Usage:
    python3 solve.py NETWORK THETA K M [TIME_LIMIT_SECONDS]
    python3 solve.py Kava 1/3 20 11
    python3 solve.py Monad 2/3 188 2 600

Prints JSON: V, v_max, k*, the allocation, the status and the solve time.
Requires pyscipopt (see requirements.txt); numpy is used if present and the
code falls back to pure Python integers if it is not.
"""
import json
import os
import sys
import time
from fractions import Fraction as F

try:
    import numpy as np
except ImportError:                      # pure-Python fallback
    np = None

from pyscipopt import Model, Conshdlr, SCIP_RESULT, quicksum

HERE = os.path.dirname(os.path.abspath(__file__))
SEP_SCALE = 100000


# --------------------------------------------------------------- exact oracle
class Oracle(object):
    """k*(v), by dynamic programming over ticket sums, exactly."""

    SHIFT = 45
    BASE = 1 << 45

    def __init__(self, w, theta):
        self.w = [int(x) for x in w]
        self.n = len(self.w)
        self.W = sum(self.w)
        self.q = (theta.numerator * self.W) // theta.denominator + 1
        self.cap = self.W - self.q
        self.big = self.W >= (1 << 62)
        if np is not None:
            if not self.big:
                self.wa = np.array(self.w, dtype=np.int64)
                self.INF = np.int64(1) << 62
            else:
                M = self.BASE - 1
                self.whi = np.array([x >> self.SHIFT for x in self.w],
                                    dtype=np.int64)
                self.wlo = np.array([x & M for x in self.w], dtype=np.int64)
                self.caphi = self.cap >> self.SHIFT
                self.caplo = self.cap & M
                self.INFHI = np.int64(1) << 50

    def qualifies(self, S):
        return sum(self.w[i] for i in S) >= self.q

    def _dp_py(self, v, V):
        minw = [None] * (V + 1)
        minw[0] = 0
        take = [bytearray(V + 1) for _ in range(self.n)]
        for i, (vi, wi) in enumerate(zip(v, self.w)):
            if vi <= 0 or vi > V:
                continue
            row = take[i]
            for t in range(V, vi - 1, -1):
                a = minw[t - vi]
                if a is not None and (minw[t] is None or a + wi < minw[t]):
                    minw[t] = a + wi
                    row[t] = 1
        tmax = max(t for t in range(V + 1)
                   if minw[t] is not None and minw[t] <= self.cap)
        return tmax, take

    def _dp_np_small(self, v, V):
        minw = np.full(V + 1, self.INF, dtype=np.int64)
        minw[0] = 0
        take = np.zeros((self.n, V + 1), dtype=bool)
        for i in range(self.n):
            vi = v[i]
            if vi <= 0 or vi > V:
                continue
            cand = minw[:V + 1 - vi] + self.wa[i]
            tgt = minw[vi:]
            imp = cand < tgt
            take[i, vi:] = imp
            minw[vi:] = np.where(imp, cand, tgt)
        return int(np.nonzero(minw <= self.cap)[0][-1]), take

    def _dp_np_big(self, v, V):
        M = self.BASE - 1
        hi = np.full(V + 1, self.INFHI, dtype=np.int64)
        lo = np.zeros(V + 1, dtype=np.int64)
        hi[0] = 0
        take = np.zeros((self.n, V + 1), dtype=bool)
        for i in range(self.n):
            vi = v[i]
            if vi <= 0 or vi > V:
                continue
            clo = lo[:V + 1 - vi] + self.wlo[i]
            carry = clo >> self.SHIFT
            clo = clo & M
            chi = hi[:V + 1 - vi] + self.whi[i] + carry
            thi, tlo = hi[vi:], lo[vi:]
            imp = (chi < thi) | ((chi == thi) & (clo < tlo))
            take[i, vi:] = imp
            hi[vi:] = np.where(imp, chi, thi)
            lo[vi:] = np.where(imp, clo, tlo)
        ok = np.nonzero((hi < self.caphi) |
                        ((hi == self.caphi) & (lo <= self.caplo)))[0]
        return int(ok[-1]), take

    def maxticket(self, v):
        v = [int(x) for x in v]
        V = sum(v)
        if np is None:
            tmax, take = self._dp_py(v, V)
        elif self.big:
            tmax, take = self._dp_np_big(v, V)
        else:
            tmax, take = self._dp_np_small(v, V)
        T, t = [], tmax
        for i in range(self.n - 1, -1, -1):
            if v[i] and take[i][t]:
                T.append(i)
                t -= v[i]
        return tmax, T

    def kstar(self, v):
        return sum(int(x) for x in v) - self.maxticket(v)[0]

    def violated(self, v, k):
        V = sum(int(x) for x in v)
        tmax, T = self.maxticket(v)
        if V - tmax >= k:
            return None
        Tset = set(T)
        return [i for i in range(self.n) if i not in Tset]

    def minimalise(self, S):
        S2 = sorted(S, key=lambda i: self.w[i])
        tot = sum(self.w[i] for i in S2)
        j = 0
        while j < len(S2) - 1 and tot - self.w[S2[j]] >= self.q:
            tot -= self.w[S2[j]]
            j += 1
        return sorted(S2[j:])


def nu(w, theta):
    W = sum(w)
    s = 0
    for k, x in enumerate(sorted(w, reverse=True), 1):
        s += x
        if s * theta.denominator > theta.numerator * W:
            return k
    return len(w)


# ------------------------------------------------------------------ seed rows
def seed_sets(O):
    n = O.n
    order = sorted(range(n), key=lambda i: (-O.w[i], i))
    light = order[::-1]
    out = set()

    def add(S):
        if sum(O.w[i] for i in S) >= O.q:
            out.add(tuple(O.minimalise(S)))

    for base in (order, light):                 # heaviest and lightest prefixes
        tot = 0
        for j, i in enumerate(base):
            tot += O.w[i]
            if tot >= O.q:
                add(base[:j + 1])
                break
    for base in (order, light):                 # each validator plus a completion
        for i in range(n):
            S, tot = [i], O.w[i]
            for j in base:
                if tot >= O.q:
                    break
                if j != i:
                    S.append(j)
                    tot += O.w[j]
            add(S)
    return sorted(out)


def variants(O, S):
    out = [tuple(sorted(S))]
    m1 = tuple(O.minimalise(S))
    if m1 not in out:
        out.append(m1)
    S2 = sorted(S, key=lambda i: -O.w[i])
    tot = sum(O.w[i] for i in S2)
    j = 0
    while j < len(S2) - 1 and tot - O.w[S2[j]] >= O.q:
        tot -= O.w[S2[j]]
        j += 1
    m2 = tuple(sorted(S2[j:]))
    if m2 not in out:
        out.append(m2)
    return out


class CoverageConshdlr(Conshdlr):
    def __init__(self, O, v, k):
        self.O, self.v, self.k = O, v, k
        self.ncuts = 0

    def _vals(self, sol):
        return [self.model.getSolVal(sol, self.v[i]) for i in range(self.O.n)]

    def _violated(self, vals):
        if all(abs(x - round(x)) < 1e-6 for x in vals):
            return self.O.violated([int(round(x)) for x in vals], self.k)
        sv = [max(0, int(x * SEP_SCALE)) for x in vals]
        if sum(sv) == 0:
            return list(range(self.O.n))
        tmax, T = self.O.maxticket(sv)
        Tset = set(T)
        S = [i for i in range(self.O.n) if i not in Tset]
        if sum(vals[i] for i in S) < self.k - 1e-6:
            return S
        return None

    def _add(self, S):
        for T in variants(self.O, S):
            self.model.addCons(quicksum(self.v[i] for i in T) >= self.k,
                               local=False)
            self.ncuts += 1

    def conscheck(self, constraints, solution, checkintegrality, checklprows,
                  printreason, completely):
        iv = [int(round(x)) for x in self._vals(solution)]
        if self.O.violated(iv, self.k) is None:
            return {"result": SCIP_RESULT.FEASIBLE}
        return {"result": SCIP_RESULT.INFEASIBLE}

    def consenfolp(self, constraints, nusefulconss, solinfeasible):
        S = self._violated(self._vals(None))
        if S is None:
            return {"result": SCIP_RESULT.FEASIBLE}
        self._add(S)
        return {"result": SCIP_RESULT.CONSADDED}

    def consenfops(self, constraints, nusefulconss, solinfeasible,
                   objinfeasible):
        S = self._violated(self._vals(None))
        if S is None:
            return {"result": SCIP_RESULT.FEASIBLE}
        self._add(S)
        return {"result": SCIP_RESULT.CONSADDED}

    def conslock(self, constraint, locktype, nlockspos, nlocksneg):
        for i in range(self.O.n):
            self.model.addVarLocks(self.v[i], nlockspos + nlocksneg,
                                   nlockspos + nlocksneg)


def solve(network, theta, k, m, timelimit=1800.0, verbose=False):
    w = json.load(open(os.path.join(HERE, "stakes.json")))[network]
    n = len(w)
    th = F(theta)
    O = Oracle(w, th)

    mdl = Model("allocation")
    if not verbose:
        mdl.hideOutput()
    mdl.setParam("limits/time", timelimit)
    mdl.setParam("parallel/maxnthreads", 1)
    mdl.setParam("misc/allowstrongdualreds", False)
    mdl.setParam("misc/allowweakdualreds", False)

    v = [mdl.addVar(vtype="I", lb=0, ub=m, name="v%d" % i) for i in range(n)]
    mdl.setObjective(quicksum(v), "minimize")
    order = sorted(range(n), key=lambda i: (-w[i], i))
    for a, b in zip(order, order[1:]):
        mdl.addCons(v[a] >= v[b])
    for S in seed_sets(O):
        mdl.addCons(quicksum(v[i] for i in S) >= k)

    hdlr = CoverageConshdlr(O, v, k)
    mdl.includeConshdlr(hdlr, "coverage", "v(S) >= k for qualifying S",
                        chckpriority=-10, enfopriority=-10, needscons=False)

    t0 = time.time()
    mdl.optimize()
    secs = time.time() - t0
    if mdl.getNSols() == 0:
        return {"network": network, "theta": theta, "k": k, "m": m,
                "status": mdl.getStatus(), "V": None,
                "seconds": round(secs, 2)}
    best = mdl.getBestSol()
    val = [int(round(mdl.getSolVal(best, v[i]))) for i in range(n)]
    ks = O.kstar(val)
    return {"network": network, "theta": theta, "k": k, "m": m,
            "status": mdl.getStatus(), "V": sum(val), "v_max": max(val),
            "k_star": ks, "nu_theta": nu(w, th),
            "max": n * max(val) / float(ks), "avg": sum(val) / float(ks),
            "bound": round(mdl.getDualbound(), 3), "cuts": hdlr.ncuts,
            "seconds": round(secs, 2), "v": val}


if __name__ == "__main__":
    if len(sys.argv) < 5:
        print(__doc__)
        sys.exit(2)
    r = solve(sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]),
              float(sys.argv[5]) if len(sys.argv) > 5 else 1800.0)
    print(json.dumps(r, indent=1))
