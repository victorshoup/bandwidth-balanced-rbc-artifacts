#!/usr/bin/env python3
"""The exact evaluator, shared by allocate.py, bound.py and solve.py.

For an allocation v (v_i fragments held by validator i) and a stake threshold
theta, a set S of validators qualifies when w(S) > theta*W.  The largest valid
reconstruction threshold is

    k*(v) = V - max{ v(T) : w(T) <= W - q },   q = floor(theta*W) + 1,

because S qualifies exactly when its complement T has w(T) <= W - q.  The inner
maximum is a 0/1 knapsack over ticket sums, solved by dynamic programming in
exact integer arithmetic.  numpy is used when present (int64, or two 45-bit
limbs when the stakes exceed 2^62); otherwise the code falls back to pure
Python integers.  The result is identical either way.

No solver is imported here.
"""
from fractions import Fraction as F

try:
    import numpy as np
except ImportError:                      # pure-Python fallback
    np = None


# --------------------------------------------------------------- exact oracle
class Oracle(object):
    """k*(v), by dynamic programming over ticket sums, exactly."""

    SHIFT = 45
    BASE = 1 << 45

    def __init__(self, w, theta):
        self.w = [int(x) for x in w]
        self.n = len(self.w)
        self.W = sum(self.w)
        self.q = (theta.numerator * self.W) // theta.denominator + 1
        self.cap = self.W - self.q
        self.big = self.W >= (1 << 62)
        if np is not None:
            if not self.big:
                self.wa = np.array(self.w, dtype=np.int64)
                self.INF = np.int64(1) << 62
            else:
                M = self.BASE - 1
                self.whi = np.array([x >> self.SHIFT for x in self.w],
                                    dtype=np.int64)
                self.wlo = np.array([x & M for x in self.w], dtype=np.int64)
                self.caphi = self.cap >> self.SHIFT
                self.caplo = self.cap & M
                self.INFHI = np.int64(1) << 50

    def qualifies(self, S):
        return sum(self.w[i] for i in S) >= self.q

    def _dp_py(self, v, V):
        minw = [None] * (V + 1)
        minw[0] = 0
        take = [bytearray(V + 1) for _ in range(self.n)]
        for i, (vi, wi) in enumerate(zip(v, self.w)):
            if vi <= 0 or vi > V:
                continue
            row = take[i]
            for t in range(V, vi - 1, -1):
                a = minw[t - vi]
                if a is not None and (minw[t] is None or a + wi < minw[t]):
                    minw[t] = a + wi
                    row[t] = 1
        tmax = max(t for t in range(V + 1)
                   if minw[t] is not None and minw[t] <= self.cap)
        return tmax, take

    def _dp_np_small(self, v, V):
        minw = np.full(V + 1, self.INF, dtype=np.int64)
        minw[0] = 0
        take = np.zeros((self.n, V + 1), dtype=bool)
        for i in range(self.n):
            vi = v[i]
            if vi <= 0 or vi > V:
                continue
            cand = minw[:V + 1 - vi] + self.wa[i]
            tgt = minw[vi:]
            imp = cand < tgt
            take[i, vi:] = imp
            minw[vi:] = np.where(imp, cand, tgt)
        return int(np.nonzero(minw <= self.cap)[0][-1]), take

    def _dp_np_big(self, v, V):
        M = self.BASE - 1
        hi = np.full(V + 1, self.INFHI, dtype=np.int64)
        lo = np.zeros(V + 1, dtype=np.int64)
        hi[0] = 0
        take = np.zeros((self.n, V + 1), dtype=bool)
        for i in range(self.n):
            vi = v[i]
            if vi <= 0 or vi > V:
                continue
            clo = lo[:V + 1 - vi] + self.wlo[i]
            carry = clo >> self.SHIFT
            clo = clo & M
            chi = hi[:V + 1 - vi] + self.whi[i] + carry
            thi, tlo = hi[vi:], lo[vi:]
            imp = (chi < thi) | ((chi == thi) & (clo < tlo))
            take[i, vi:] = imp
            hi[vi:] = np.where(imp, chi, thi)
            lo[vi:] = np.where(imp, clo, tlo)
        ok = np.nonzero((hi < self.caphi) |
                        ((hi == self.caphi) & (lo <= self.caplo)))[0]
        return int(ok[-1]), take

    def maxticket(self, v):
        v = [int(x) for x in v]
        V = sum(v)
        if np is None:
            tmax, take = self._dp_py(v, V)
        elif self.big:
            tmax, take = self._dp_np_big(v, V)
        else:
            tmax, take = self._dp_np_small(v, V)
        T, t = [], tmax
        for i in range(self.n - 1, -1, -1):
            if v[i] and take[i][t]:
                T.append(i)
                t -= v[i]
        return tmax, T

    def kstar(self, v):
        return sum(int(x) for x in v) - self.maxticket(v)[0]

    def violated(self, v, k):
        V = sum(int(x) for x in v)
        tmax, T = self.maxticket(v)
        if V - tmax >= k:
            return None
        Tset = set(T)
        return [i for i in range(self.n) if i not in Tset]

    def minimalise(self, S):
        S2 = sorted(S, key=lambda i: self.w[i])
        tot = sum(self.w[i] for i in S2)
        j = 0
        while j < len(S2) - 1 and tot - self.w[S2[j]] >= self.q:
            tot -= self.w[S2[j]]
            j += 1
        return sorted(S2[j:])


def nu(w, theta):
    W = sum(w)
    s = 0
    for k, x in enumerate(sorted(w, reverse=True), 1):
        s += x
        if s * theta.denominator > theta.numerator * W:
            return k
    return len(w)


# ------------------------------------------------------------------ seed rows
def seed_sets(O):
    n = O.n
    order = sorted(range(n), key=lambda i: (-O.w[i], i))
    light = order[::-1]
    out = set()

    def add(S):
        if sum(O.w[i] for i in S) >= O.q:
            out.add(tuple(O.minimalise(S)))

    for base in (order, light):                 # heaviest and lightest prefixes
        tot = 0
        for j, i in enumerate(base):
            tot += O.w[i]
            if tot >= O.q:
                add(base[:j + 1])
                break
    for base in (order, light):                 # each validator plus a completion
        for i in range(n):
            S, tot = [i], O.w[i]
            for j in base:
                if tot >= O.q:
                    break
                if j != i:
                    S.append(j)
                    tot += O.w[j]
            add(S)
    return sorted(out)


# ------------------------------------------------------ bounded exact oracle
class TicketOracle(object):
    """Bounded exact minimum-cost qualifying sets, by DP over ticket cost.

    For a budget U >= 0 a 0/1 knapsack indexed by ticket cost t = 0..U that
    maximises stake gives

        best[t] = max{ w(S) : v(S) <= t },    k*(v) = min{ t : best[t] >= q },

    so one run decides whether k*(v) <= U and, when it is, returns k*(v)
    together with an explicit qualifying set S with v(S) = k*(v).  This works
    directly on qualifying sets, not on complements, and its table has U + 1
    entries instead of V + 1.

    Validators of equal cost form one group: among items of equal cost the
    best choice of k of them is the k heaviest, so a group of cost c turns
    best[] into  max_k best[t - k*c] + (sum of its k heaviest stakes).
    Validators with v_i = 0 cost nothing and always join (their stake is a
    base).  Validators with v_i > U cannot belong to a set of cost <= U.

    numpy int64 is used when W < 2^62, so that every sum of stakes fits;
    otherwise (or when numpy is absent, or python=True) Python integers.  The
    results are identical.  Everything is exact integer arithmetic.
    """

    def __init__(self, w, theta, python=False):
        self.w = [int(x) for x in w]
        self.n = len(self.w)
        self.W = sum(self.w)
        self.q = (theta.numerator * self.W) // theta.denominator + 1
        self.desc = sorted(range(self.n), key=lambda i: (-self.w[i], i))
        self.rank = [0] * self.n
        for r, i in enumerate(self.desc):
            self.rank[i] = r
        self.use_np = (np is not None and not python and
                       self.W < (1 << 62))
        if self.use_np:
            self.desc_a = np.array(self.desc, dtype=np.int64)
            self.wd = np.array([self.w[i] for i in self.desc], dtype=np.int64)
            self.NEG = -(1 << 62)

    # -- public interface ------------------------------------------------
    def kstar_upto(self, v, U):
        """(k*(v), S) if k*(v) <= U, with S qualifying and v(S) = k*(v);
        otherwise (None, None), which proves k*(v) > U."""
        return self.min_cost(v, self.q, U, -1)

    def violating(self, v, k):
        """A qualifying set S with v(S) < k, or None if k*(v) >= k."""
        return self.kstar_upto(v, k - 1)[1]

    def forced_cost(self, v, i, U):
        """r_i = min{ v(R) : R excludes i, w(R) >= q - w_i }, truncated at U.

        Returns (r_i, R) when r_i <= U, else (None, None).  Validators other
        than i holding no fragment contribute their stake at zero cost."""
        return self.min_cost(v, self.q - self.w[i], U, i)

    def min_cost(self, v, need, U, exclude):
        """min{ v(S) : w(S) >= need, exclude not in S }, if it is <= U."""
        if U < 0:
            return None, None
        if need <= 0:
            return 0, []
        if self.use_np:
            return self._np(v, need, U, exclude)
        return self._py(v, need, U, exclude)

    # -- pure Python -----------------------------------------------------
    def _py(self, v, need, U, exclude):
        w = self.w
        free = []
        groups = {}
        for i in self.desc:                  # heaviest first, ties by index
            if i == exclude:
                continue
            c = v[i]
            if c == 0:
                need -= w[i]
                free.append(i)
            elif c <= U:
                g = groups.get(c)
                if g is None:
                    groups[c] = [i]
                else:
                    g.append(i)
        if need <= 0:
            return 0, free
        best = [0] * (U + 1)
        steps = []
        for c in sorted(groups):
            items = groups[c]
            K = min(len(items), U // c)
            P = [0]
            for i in items[:K]:
                P.append(P[-1] + w[i])
            new = best[:]
            for k in range(1, K + 1):
                off, add = k * c, P[k]
                new[off:] = [a if a >= b + add else b + add
                             for a, b in zip(new[off:], best)]
            steps.append((c, items, K, P, best))
            best = new
        if best[U] < need:
            return None, None
        t = 0
        while best[t] < need:                # best[] is nondecreasing
            t += 1
        return t, self._back(best, steps, t, free)

    # -- numpy int64 -----------------------------------------------------
    def _np(self, v, need, U, exclude):
        vd = np.asarray(v, dtype=np.int64)[self.desc_a]
        if exclude >= 0:
            vd[self.rank[exclude]] = U + 1   # never selectable
        zero = vd == 0
        need -= int(self.wd[zero].sum())
        if need <= 0:
            return 0, self.desc_a[zero].tolist()
        pos = np.flatnonzero((vd > 0) & (vd <= U))
        cost = vd[pos]
        o = np.argsort(cost, kind="stable")  # by cost, then heaviest first
        pos, cost = pos[o], cost[o]
        cuts = (np.flatnonzero(cost[1:] != cost[:-1]) + 1).tolist()
        starts = [0] + cuts if len(pos) else []
        ends = cuts + [len(pos)]
        best = np.zeros(U + 1, dtype=np.int64)
        steps = []
        for s, e in zip(starts, ends):
            c = int(cost[s])
            K = min(e - s, U // c)
            gp = pos[s:s + K]
            P = np.zeros(K + 1, dtype=np.int64)
            np.cumsum(self.wd[gp], out=P[1:])
            pad = np.empty(K * c + U + 1, dtype=np.int64)
            pad[:K * c] = self.NEG
            pad[K * c:] = best
            # row r of the view is best[t - (K - r)*c], t = 0..U
            view = np.ndarray((K + 1, U + 1), dtype=np.int64, buffer=pad,
                              strides=(8 * c, 8))
            new = (view + P[::-1, None]).max(axis=0)
            steps.append((c, self.desc_a[gp].tolist(), K, P.tolist(), best))
            best = new
        if best[U] < need:
            return None, None
        t = int(np.searchsorted(best, need))
        return t, self._back(best, steps, t,
                             self.desc_a[zero].tolist())

    # -- reconstruction --------------------------------------------------
    @staticmethod
    def _back(best, steps, t, S):
        S = list(S)
        cur = best
        for c, items, K, P, prev in reversed(steps):
            target = cur[t]
            for k in range(min(K, t // c) + 1):
                if prev[t - k * c] + P[k] == target:
                    break
            else:
                raise AssertionError("knapsack reconstruction failed")
            S.extend(items[:k])
            t -= k * c
            cur = prev
        return S
