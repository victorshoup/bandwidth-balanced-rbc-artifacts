#!/usr/bin/env python3
"""Capped Swiper, the paper's allocation procedure.  No solver; exact; deterministic.

Given the stakes w (stakes.json), a threshold theta, a band on the maximum and a
bound B on the number of fragments V, it returns an allocation v (v_i fragments
for validator i) and a reconstruction threshold k = k*(v).

Family.  With p_i = w_i / W and the single offset c = 1 - theta,

    v_i = min(m, floor(s * p_i + c)),        m = 1, ..., floor(band * B / nu_theta).

No larger cap is needed: an allocation within the band has
v_max <= band * k*/nu_theta <= band * V/nu_theta <= band * B/nu_theta.

Search, for each cap m.  s increases from 0.  v changes only at the
breakpoints s = (j - c)/p_i; fragments are added one at a time, and validators
that reach a breakpoint at the same s are taken in stakes.json order, so the
t-th candidate has V = t.  The search stops at the first v with k*(v) >= 1 and
n*v_max/k* <= band * n/nu_theta (the band), or when V would exceed B.

Candidates.  These per-m results with V <= B, and always one fragment per
validator (v_i = 1 for all i), which is within the band and the bound.

Winner.  The lowest avg = V/k*; ties by smaller V, then by smaller m, with the
one-fragment-per-validator candidate after every m.

Trim.  Visit validators in increasing stake order (ties in stakes.json order)
and decrement v_i while k* does not drop and the band still holds.

Costs, in units of |M|: max = n*v_max/k*, avg = V/k*.  For theta = 2/3 the
allocation is the MiniCast main code.  The recovery code uses Capped Swiper at
theta = 1/3 with the same band and bound B.  Write A1 = V1/k1, A2 = V2/k2:

    max = max_i(n*v_i/k1 + A1*u_i/k2),   avg = A1*(1 + A2/n).

Each code separately has at most B fragments.  The recovery allocation is
computed even when only --theta 2/3 is selected; repeated settings are cached.
The protocol maximum is within the band of Balanced MiniCast: A1 <= n/nu_{2/3}
because one fragment per validator is always a candidate, and each allocation
separately satisfies its maximum-cost band.

Everything is exact: Fractions for s, p_i, c and the band; integers for v and
k*.  Standard library plus oracle.py (numpy optional, same results).

Implementation.  The results are exactly those of allocate_reference.py, the
original one-state-at-a-time implementation, kept for differential testing
(tests/); only the computation differs.  Proofs and measurements are in
PERFORMANCE_OPTIMIZATION_REPORT.md.
  * Breakpoints: one sorted list of all pairs (i, j), with exact integer
    keys that preserve the scan order and its ties.
  * Caps: cap m's states agree with cap m-1's before a_m, the first state
    giving the heaviest validator its m-th fragment, so cap m inherits cap
    m-1's result when that came before a_m.  On [a_m, T_m] the maximum is
    held by the heaviest validator and acceptance is k* >= K_m, which is
    monotone, so the first accepted state is found by binary search.
  * Probes: a DP over fragment cost 0..K_m (TicketOracle) decides
    k* >= K_m and returns k* exactly when k* = K_m; a failing probe's
    qualifying set rules out every later state in which it still fails.
  * Trim: same order, same result; for each validator the loop's endpoint
    comes from max-plus combinations of a prefix table (validators already
    trimmed) and a suffix table (validators not yet visited), built once;
    no k* DP.
Custom non-consecutive caps, and parameters outside 0 < theta < 1, band > 0,
fall back to allocate_reference.

Usage:
    python3 allocate.py [NETWORK ... | all] [--theta 1/3 [2/3]] [--band 11/10 [1]]
                        [--bound 4 [2]] [--json FILE] [--check]

    --bound is a multiple of n (4 means V <= 4n).  Several values may be given
    for --theta, --band and --bound; every combination is run.  Defaults:
    all networks, both thetas, band 11/10, bound 4 (the paper's Table 2).
    --check compares each result with the record of allocations.json that it
    should reproduce (table2:*:4n for band 11/10 and bound 4, table2:*:4n:band1
    for band 1 and bound 4, text:*:2n for band 11/10 and bound 2) and exits
    non-zero on any difference.
    --json writes every result, including both MiniCast allocations, to FILE.
    The seconds column includes any recovery computation needed for that row.

Examples:
    python3 allocate.py --check
    python3 allocate.py Monad --theta 1/3 --band 11/10 --bound 4
    python3 allocate.py all --theta 1/3 2/3 --band 1 11/10 --bound 2 4
"""
import json
import math
import os
import sys
import time
from fractions import Fraction as F

from oracle import Oracle, TicketOracle, nu, np

HERE = os.path.dirname(os.path.abspath(__file__))
ORDER = ["Monad", "Kava", "Sui", "dYdX", "Sei", "Osmosis", "Injective", "Neutron"]

# Mechanisms, all on by default; the switches exist for the ablation timings
# in PERFORMANCE_OPTIMIZATION_REPORT.md.  Every combination is exact.
DEFAULT_OPTS = dict(
    bisect=True,        # binary search on [a_m, T_m] (off: linear scan from a_m)
    bounded=True,       # bounded ticket DP at probes (off: full Oracle.kstar)
    witness=True,       # explicit-witness guards: skip states a cached set
                        # still proves failing (measured: 3.6x fewer probes)
    shave="split",      # "split": prefix/suffix DP reuse, no k* DPs (report)
                        # "direct": one forced-inclusion DP per validator
                        # "reference": the original repeated-decrement loop
    tight=False,        # tight-set cache during shaving: True caches every
                        # tight set found, "seed" only the winner's; both
                        # exact, neither measurably faster with "split"
    check=False,        # re-verify witnesses and tight sets (used by the tests)
)

STAT_KEYS = (
    # scan
    "caps", "caps_inherited", "caps_empty_suffix", "caps_searched",
    "reference_states", "prefix_states_skipped", "suffix_states",
    "probes", "witness_states_skipped", "decision_dp", "full_kstar_scan",
    # trim
    "trim_validators", "trim_considered", "trim_reference_trials",
    "trim_suffix_updates", "trim_prefix_updates", "trim_maxplus",
    "trim_forced_dp", "trim_tight_skips", "trim_tight_sets",
    "trim_fragments_removed", "full_kstar_trim",
    "trim_check_kstar",      # debug-only k* checks (opt["check"]), not timed
    "trim_seconds",          # wall-clock time of the trim phase
)


def new_stats():
    return dict.fromkeys(STAT_KEYS, 0)


def ceil_div(a, b):
    return -((-a) // b)


# ------------------------------------------------------------ breakpoints
def breakpoints(w, c, M):
    """Every pair (i, j), w_i > 0, 1 <= j <= M, in Swiper's scan order.

    The scan pops the pair with the least (s, i), s = (j - c) * W / w_i
    (exact Fractions).  With c = cn/cd this orders pairs exactly as the
    rational (j*cd - cn) / w_i.  Two distinct such rationals differ by at
    least 1/(w_i w_k) > 2^-K for K = 2*maxbits, so
    floor((j*cd - cn) * 2^K / w_i) preserves strict order and equality;
    ties are then broken by i as in the heap.  Returns (validators, j's).
    """
    cn, cd = c.numerator, c.denominator
    K = 2 * max(x.bit_length() for x in w) + 1
    keys = []
    for i, wi in enumerate(w):
        if wi > 0:
            num = ((cd - cn) << K)
            step = cd << K
            for j in range(1, M + 1):
                keys.append((num // wi, i, j))
                num += step
    keys.sort()
    return [x[1] for x in keys], [x[2] for x in keys]


# ------------------------------------------------------------------- trim
def trim_reference(w, v, nv, band, kstar, st=None, trace=None):
    """The original loop: increasing stake order; decrement while k* holds.

    Identical to allocate_reference.trim, plus optional counters (one
    "trial" per attempted decrement) and trace(i, v) after each validator.
    """
    v = list(v)
    ks0 = kstar(v)
    for i in sorted(range(len(v)), key=lambda j: (w[j], j)):
        while v[i] > 0:
            v[i] -= 1
            if st is not None:
                st["trim_reference_trials"] += 1
            ks = kstar(v)
            if ks < ks0 or ks <= 0 or max(v) * nv > band * ks:
                v[i] += 1
                break
            if st is not None:
                st["trim_fragments_removed"] += 1
        if trace is not None:
            trace(i, list(v))
    return v


def _t_zero(L, use_np):
    return np.zeros(L, dtype=np.int64) if use_np else [0] * L


def _t_add(T, c, wi, use_np):
    """Add one 0/1 item (cost c, stake wi) to T[b] = max{w(S): v(S) <= b}.

    Returns a new table.  A zero-cost item raises every entry by wi exactly
    once; an item costing more than the largest budget changes nothing.
    """
    L = len(T)
    if c >= L:
        return T
    if use_np:
        if c == 0:
            return T + wi
        new = T.copy()
        np.maximum(T[c:], T[:L - c] + wi, out=new[c:])
        return new
    if c == 0:
        return [a + wi for a in T]
    return T[:c] + [a if a >= b + wi else b + wi
                    for a, b in zip(T[c:], T)]


def _t_maxplus(pre, suf, C, use_np):
    """F(C) = max{ pre[a] + suf[C - a] : 0 <= a <= C }."""
    if use_np:
        return int((pre[:C + 1] + suf[C::-1]).max())
    return max(a + b for a, b in zip(pre[:C + 1], reversed(suf[:C + 1])))


def _t_back(tables, items, costs, t):
    """Items taken to reach tables[-1][t]; tables[k+1] = tables[k] + item k."""
    S = []
    for k in range(len(items) - 1, -1, -1):
        if tables[k + 1][t] != tables[k][t]:
            S.append(items[k])
            t -= costs[k]
    return S


def trim_fast(O, v, nv, band, k0, seeds, opt, st, trace=None, kcheck=None,
              probe=None):
    """Shaving with prefix/suffix DP reuse; same order and result as the loop.

    Visit validators in increasing (w_i, i) (position p = 0..n-1).  When
    validator i is visited, those before it hold their final values, those
    after it their values from before the trim, and k*(v) = k0.  Setting
    v_i = t keeps k* = k0 exactly when

        C = k0 - 1 - t < 0   or   w_i + F_i(C) < q,
        F_i(C) = max{ w(R) : i not in R, v(R) <= C }
               = max_{0<=a<=C} ( pre[a] + suf[p+1][C-a] ),

    where pre[] ranges over the validators before i (final values) and
    suf[p+1][] over those after it (values before the trim), both tables of
    the largest stake at fragment cost <= b, b = 0..k0-1.  The predicate
    is monotone in t and holds at the current v_i, and the reference loop
    stops exactly at the least t for which it holds, which a binary search
    finds.  suf[] is built once, backwards; pre[] gains one item (the final
    v_i) per validator.  No k* DP is run.  Proofs: see
    PERFORMANCE_OPTIMIZATION_REPORT.md, "Shaving".

    shave="direct" computes the same boundary with one bounded DP per
    validator (the forced-inclusion formulation; a cross-check).  A tight
    set S (qualifying, v(S) = k0) makes each of its members unshavable, and
    stays tight while only non-members change, so members can be skipped
    (opt["tight"]).  trace(i, v), if given, receives the state after each
    validator; with opt["check"], kcheck(v) must return k0 after each one.
    probe(p, i, v, pre, suf), if given, receives the two tables that test
    validator i (shave="split"), for the table tests.
    """
    w, q, n = O.w, O.q, O.n
    v = list(v)
    order = sorted(range(n), key=lambda j: (w[j], j))
    L = k0                                   # budgets 0..k0-1
    use_np = O.use_np
    split = opt["shave"] == "split"
    keep = opt["tight"] is True              # keep every prefix table
    blocked = [None] * n                     # tight set containing i, if known
    # k* is held at k0 and entries only decrease, so the band, which holds
    # at the start, holds throughout.
    assert k0 >= 1 and max(v) * nv <= band * k0

    def cache(S):
        S = sorted(set(S))
        if opt["check"]:
            assert sum(w[j] for j in S) >= q and sum(v[j] for j in S) == k0
        st["trim_tight_sets"] += 1
        for j in S:
            if blocked[j] is None:
                blocked[j] = S

    if opt["tight"]:
        for S in seeds:
            cache(S)
    if split:
        suf = [None] * (n + 1)               # suf[p]: over order[p:]
        suf[n] = _t_zero(L, use_np)
        for p in range(n - 1, -1, -1):
            i = order[p]
            suf[p] = _t_add(suf[p + 1], v[i], w[i], use_np)
            st["trim_suffix_updates"] += 1
        pre = _t_zero(L, use_np)             # over order[:p]
        pres = [pre] if keep else None
    for p, i in enumerate(order):
        st["trim_validators"] += 1
        if probe is not None and split:
            probe(p, i, list(v), pre, suf[p + 1])
        x = v[i]
        if x > 0:
            st["trim_considered"] += 1
            S = blocked[i] if opt["tight"] else None
            R = None
            skipped = S is not None
            if skipped:
                st["trim_tight_skips"] += 1
                if opt["check"]:
                    assert (sum(w[j] for j in S) >= q and
                            sum(v[j] for j in S) == k0 and i in S)
                t = x
            elif split:
                sk = suf[p + 1]

                def safe(t):
                    C = k0 - 1 - t
                    if C < 0:
                        return True
                    st["trim_maxplus"] += 1
                    return w[i] + _t_maxplus(pre, sk, C, use_np) < q

                if opt["check"]:
                    assert safe(x)
                lo, hi = 0, x                # safe(hi); least safe t
                while lo < hi:
                    mid = (lo + hi) // 2
                    if safe(mid):
                        hi = mid
                    else:
                        lo = mid + 1
                t = lo
            else:
                st["trim_forced_dp"] += 1
                need = q - w[i]
                if need <= 0:
                    r, R = 0, []
                else:
                    r, R = O.forced_cost(v, i, L - 1)
                t = 0 if r is None else k0 - r
            assert 0 <= t <= x
            # the loop tries x - t decrements that succeed, then one that
            # fails unless it reached 0
            st["trim_reference_trials"] += x - t + (t > 0)
            st["trim_fragments_removed"] += x - t
            v[i] = t
            if t > 0 and keep and not skipped:   # {i} + R is tight
                if R is None:                # recover R from the tables
                    C = k0 - t
                    pk, sk = pres[p], suf[p + 1]
                    a = next(a for a in range(C + 1)
                             if w[i] + pk[a] + sk[C - a] >= q)
                    R = (_t_back(pres, order[:p], [v[j] for j in order[:p]],
                                 a) +
                         _t_back(suf[p + 1:][::-1], order[p + 1:][::-1],
                                 [v[j] for j in order[p + 1:][::-1]],
                                 C - a))
                cache([i] + list(R))
        if split:
            pre = _t_add(pre, v[i], w[i], use_np)
            st["trim_prefix_updates"] += 1
            if keep:
                pres.append(pre)
        if opt["check"] and kcheck is not None:
            st["trim_check_kstar"] += 1
            assert kcheck(v) == k0
        if trace is not None:
            trace(i, list(v))
    return v


# -------------------------------------------------------------- procedure
def procedure(w, theta, band, B, caps=None, stats=None, opts=None,
              python=False):
    """Capped Swiper for one (theta, band, B).  Returns a result dict.

    Same result as allocate_reference.procedure, computed with the cap
    recursion and suffix binary search (see the report).  A caps list that
    is not 1, 2, ..., M, or parameters outside 0 < theta < 1, band > 0,
    W > 0, fall back to the reference implementation.
    """
    opt = dict(DEFAULT_OPTS)
    if opts:
        opt.update(opts)
    st = new_stats() if stats is None else stats
    for key in STAT_KEYS:
        st.setdefault(key, 0)
    n, W = len(w), sum(w)
    nv = nu(w, theta)
    c = 1 - theta
    Mcap = math.floor(band * B / nv)
    if caps is None:
        caps = list(range(1, Mcap + 1))
    caps = list(caps)
    band = F(band)
    if (caps != list(range(1, len(caps) + 1)) or not 0 < theta < 1 or
            band <= 0 or W <= 0 or any(int(x) != x or x < 0 for x in w)):
        import allocate_reference
        return allocate_reference.procedure(w, theta, band, B, caps)
    O = TicketOracle(w, theta, python=python)
    use_np = O.use_np
    full = Oracle(w, theta)
    kcache = {}
    ncalls = [0]

    def kstar_full(v):
        key = tuple(int(x) for x in v)
        ks = kcache.get(key)
        if ks is None:
            ncalls[0] += 1
            ks = full.kstar(list(key))
            kcache[key] = ks
        return ks

    bn, bd = band.numerator, band.denominator
    M = len(caps)
    Li, Lj = breakpoints(w, c, M) if M else ([], [])
    nP = sum(1 for x in w if x > 0)
    h = min(range(n), key=lambda i: (-w[i], i))
    posh = [None] + [p for p, i in enumerate(Li) if i == h]  # posh[j]
    if use_np:
        Lia = np.array(Li, dtype=np.int64)
        Lja = np.array(Lj, dtype=np.int64)
        u = np.zeros(n, dtype=np.int64)      # uncapped state after upos pairs
    else:
        u = [0] * n
    upos = 0

    cands = []
    pool = []            # recent explicit witnesses (opt["witness"])
    prev = None          # cap m-1: (t', candidate) or (None, None)
    for rank, m in enumerate(caps):
        st["caps"] += 1
        a0 = posh[m]                         # 0-based; state a_m = a0 + 1
        am = a0 + 1
        T = min(B, nP * m)
        if prev is not None and prev[0] is not None and prev[0] < am:
            # Lemma 2: same states, ACC depends only on the state.
            t1, cd = prev
            cands.append((cd[0], cd[1], rank, m, cd[4], cd[5], cd[6]))
            st["caps_inherited"] += 1
            st["reference_states"] += t1
            st["prefix_states_skipped"] += t1
            continue
        if am > T:
            # Every examined state precedes a_m and failed under cap m-1.
            prev = (None, None)
            st["caps_empty_suffix"] += 1
            st["reference_states"] += T
            st["prefix_states_skipped"] += T
            continue
        st["caps_searched"] += 1
        st["prefix_states_skipped"] += am - 1
        st["suffix_states"] += T - am + 1
        K = max(1, ceil_div(m * nv * bd, bn))   # ACC <=> k* >= K on [a_m, T]
        cnt = T - a0                         # events of the suffix
        if use_np:
            if upos < a0:
                u += np.bincount(Lia[upos:a0], minlength=n)
                upos = a0
            sel = np.flatnonzero(Lja[a0:] <= m)[:cnt]
            E = Lia[a0 + sel]
        else:
            while upos < a0:
                u[Li[upos]] += 1
                upos += 1
            E = [i for i, j in zip(Li[a0:], Lj[a0:]) if j <= m][:cnt]
        assert len(E) == cnt and E[0] == h

        def state(t):                        # allocation after t fragments
            e = t - a0                       # number of suffix events
            if use_np:
                return u + np.bincount(E[:e], minlength=n)
            v = list(u)
            for i in E[:e]:
                v[i] += 1
            return v

        def expiry(S, frm):
            """First state >= frm at which v(S) >= K (S fails before it)."""
            if use_np:
                mask = np.zeros(n, dtype=bool)
                mask[S] = True
                base = int(u[mask].sum())
                hits = np.cumsum(mask[E])
                e = int(np.searchsorted(hits, K - base))
                return max(frm, a0 + 1 + e)
            inS = set(S)
            s = sum(u[i] for i in S)
            for e, i in enumerate(E):
                if i in inS:
                    s += 1
                if s >= K:
                    return max(frm, a0 + 1 + e)
            return max(frm, T + 1)

        lo, hi, found = am, T + 1, None
        if opt["witness"]:
            for S in pool:
                x = expiry(S, lo)
                st["witness_states_skipped"] += x - lo
                lo = x
        while lo < hi:
            mid = (lo + hi) // 2 if opt["bisect"] else lo
            v = state(mid)
            st["probes"] += 1
            if opt["bounded"]:
                st["decision_dp"] += 1
                ks, S = O.kstar_upto(v, K)   # decides k* >= K; exact if = K
            else:
                ks, S = kstar_full(v), None
            if ks is not None and ks < K:    # fails: S qualifies, v(S) < K
                if opt["check"] and S is not None:
                    assert (sum(O.w[i] for i in S) >= O.q and
                            sum(int(v[i]) for i in S) == ks)
                lo = mid + 1
                if opt["witness"] and S is not None:
                    x = expiry(S, lo)
                    st["witness_states_skipped"] += x - lo
                    lo = x
                    pool.insert(0, S)
                    del pool[16:]
            else:
                hi = mid
                found = (ks, S, v)
        if hi > T:
            prev = (None, None)
            st["reference_states"] += T
            continue
        st["reference_states"] += hi
        ks, S, v = found
        if ks is None:                       # k* > K: cannot happen (report)
            st["full_kstar_scan"] += 1
            ks, S = O.kstar_upto(v, int(sum(v)))
        v = tuple(int(x) for x in v)
        cand = (F(hi, ks), hi, rank, m, v, ks, S)
        cands.append(cand)
        prev = (hi, cand)

    ones = (1,) * n
    k1, S1 = O.kstar_upto(ones, n)
    assert k1 == nv and nv <= band * k1 and n <= B
    cands.append((F(n, k1), n, len(caps), "ones", ones, k1, S1))
    win = min(cands, key=lambda z: (z[0], z[1], z[2]))
    k0 = win[5]
    st["full_kstar_scan"] += ncalls[0]
    if stats is not None:                    # for the differential tests
        stats["cands"] = [z[:6] for z in cands]
        stats["winner"] = win[:6]
    t0 = time.perf_counter()
    if opt["shave"] == "reference":
        n0 = ncalls[0]
        vt = trim_reference(w, win[4], nv, band, kstar_full, st)
        kt = kstar_full(vt)
        st["full_kstar_trim"] += ncalls[0] - n0
        st["trim_seconds"] += time.perf_counter() - t0
    else:
        seeds = [win[6]] if win[6] is not None else []
        vt = trim_fast(O, win[4], nv, band, k0, seeds, opt, st,
                       kcheck=full.kstar)
        kt = k0                              # shaving preserves k* = k0
        st["trim_seconds"] += time.perf_counter() - t0
        if opt["check"]:
            assert full.kstar(vt) == k0
    assert kt >= 1 and max(vt) * nv <= band * kt and sum(vt) <= B
    return dict(V=sum(vt), k=kt, vmax=max(vt), max=F(n * max(vt), kt),
                avg=F(sum(vt), kt), m=win[3], V_before_trim=win[1],
                k_before_trim=win[5], candidates=len(cands), v=list(vt))


def protocol(w, r, recovery):
    """Exact MiniCast costs from main and recovery allocations in input order."""
    n = len(w)
    a1 = F(r["V"], r["k"])
    a2 = F(recovery["V"], recovery["k"])
    mx = max(F(n * vi, r["k"]) + a1 * F(ui, recovery["k"])
             for vi, ui in zip(r["v"], recovery["v"]))
    av = a1 * (1 + a2 / n)
    return mx, av


def label_for(theta, band, mult):
    kind = "CT" if theta == F(1, 3) else "MiniCast"
    if band == F(11, 10) and mult == 4:
        return "table2:%s:4n" % kind
    if band == F(1) and mult == 4:
        return "table2:%s:4n:band1" % kind
    if band == F(11, 10) and mult == 2:
        return "text:%s:2n" % kind
    return None


def main(argv):
    args = list(argv)
    opts = {"--theta": ["1/3", "2/3"], "--band": ["11/10"], "--bound": ["4"]}
    jpath, check = None, False
    nets = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in opts:
            vals = []
            i += 1
            while i < len(args) and not args[i].startswith("--"):
                vals.append(args[i])
                i += 1
            opts[a] = vals
            continue
        if a == "--json":
            jpath = args[i + 1]
            i += 2
            continue
        if a == "--check":
            check = True
            i += 1
            continue
        if a in ("-h", "--help"):
            print(__doc__)
            return 0
        nets.append(a)
        i += 1
    stakes = json.load(open(os.path.join(HERE, "stakes.json")))
    if not nets or nets == ["all"]:
        nets = [x for x in ORDER if x in stakes]
    recs = json.load(open(os.path.join(HERE, "allocations.json"))) if check else []

    out, bad = [], 0
    computed = {}

    def allocation(net, th, band, mult):
        key = (net, th, band, mult)
        if key not in computed:
            computed[key] = procedure(stakes[net], th, band,
                                      mult * len(stakes[net]))
        return computed[key]

    def matches(net, th, band, mult, result):
        lab = label_for(th, band, mult)
        if lab is None:
            return None, "no record for this setting"
        hit = [x for x in recs if x["label"] == lab and
               x["network"] == net and F(x["theta"]) == th]
        ok = (len(hit) == 1 and hit[0]["v"] == result["v"] and
              hit[0]["k"] == result["k"])
        return ok, ("reproduces " if ok else "DIFFERS from ") + lab

    print("%-10s %-5s %-6s %-5s %5s %5s %5s %9s %8s %5s %5s %5s %9s %8s %8s  %s" % (
        "network", "theta", "band", "bound", "V", "k", "v_max", "max", "avg", "m",
        "V2", "k2", "prot.max", "prot.avg", "seconds", "check" if check else ""))
    for th_s in opts["--theta"]:
        th = F(th_s)
        for net in nets:
            w = stakes[net]
            n = len(w)
            for b_s in opts["--band"]:
                band = F(b_s)
                for mult_s in opts["--bound"]:
                    mult = int(mult_s)
                    t0 = time.perf_counter()
                    r = allocation(net, th, band, mult)
                    recovery = (allocation(net, F(1, 3), band, mult)
                                if th == F(2, 3) else None)
                    secs = time.perf_counter() - t0
                    pm, pa = (protocol(w, r, recovery) if recovery is not None
                              else (None, None))
                    if recovery is not None:
                        balanced = F(n, nu(w, th)) * (1 + F(1, nu(w, F(1, 3))))
                        assert r["avg"] <= F(n, nu(w, th))
                        assert pm <= band * balanced
                    status = ""
                    if check:
                        ok, status = matches(net, th, band, mult, r)
                        bad += (ok is False)
                        if recovery is not None:
                            ok2, status2 = matches(net, F(1, 3), band, mult, recovery)
                            bad += (ok2 is False)
                            status += "; recovery " + status2
                    print("%-10s %-5s %-6s %-5s %5d %5d %5d %9.3f %8.3f %5s %5s %5s %9s %8s %8.2f  %s" % (
                        net, th_s, b_s, "%dn" % mult, r["V"], r["k"], r["vmax"],
                        float(r["max"]), float(r["avg"]), r["m"],
                        "" if recovery is None else str(recovery["V"]),
                        "" if recovery is None else str(recovery["k"]),
                        "" if pm is None else "%.3f" % float(pm),
                        "" if pa is None else "%.3f" % float(pa), secs, status),
                          flush=True)
                    out.append(dict(network=net, theta=th_s, band=b_s,
                                    bound="%dn" % mult, V=r["V"], k=r["k"],
                                    vmax=r["vmax"], max=str(r["max"]),
                                    avg=str(r["avg"]), m=r["m"],
                                    V_before_trim=r["V_before_trim"],
                                    k_before_trim=r["k_before_trim"],
                                    seconds=round(secs, 3), v=r["v"]))
                    if recovery is not None:
                        out[-1].update(protocol_max=str(pm), protocol_avg=str(pa),
                                       recovery=dict(theta="1/3", V=recovery["V"],
                                                     k=recovery["k"], v=recovery["v"],
                                                     avg=str(recovery["avg"]),
                                                     max=str(recovery["max"])))
    if jpath:
        with open(jpath, "w") as fh:
            json.dump(out, fh)
    if check:
        print("\n%s" % ("all results reproduce allocations.json" if bad == 0 else
                        "%d result(s) do not reproduce allocations.json" % bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
