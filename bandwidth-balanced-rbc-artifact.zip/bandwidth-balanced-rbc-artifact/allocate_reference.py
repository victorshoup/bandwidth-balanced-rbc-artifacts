#!/usr/bin/env python3
"""Capped Swiper, the paper's allocation procedure.  No solver; exact; deterministic.

Given the stakes w (stakes.json), a threshold theta, a band on the maximum and a
bound B on the number of fragments V, it returns an allocation v (v_i fragments
for validator i) and a reconstruction threshold k = k*(v).

Family.  With p_i = w_i / W and the single offset c = 1 - theta,

    v_i = min(m, floor(s * p_i + c)),        m = 1, ..., floor(band * B / nu_theta).

No larger cap is needed: an allocation within the band has
v_max <= band * k*/nu_theta <= band * V/nu_theta <= band * B/nu_theta.

Search, for each cap m.  s increases from 0.  v changes only at the
breakpoints s = (j - c)/p_i; fragments are added one at a time, and validators
that reach a breakpoint at the same s are taken in stakes.json order, so the
t-th candidate has V = t.  The search stops at the first v with k*(v) >= 1 and
n*v_max/k* <= band * n/nu_theta (the band), or when V would exceed B.

Candidates.  These per-m results with V <= B, and always one fragment per
validator (v_i = 1 for all i), which is within the band and the bound.

Winner.  The lowest avg = V/k*; ties by smaller V, then by smaller m, with the
one-fragment-per-validator candidate after every m.

Trim.  Visit validators in increasing stake order (ties in stakes.json order)
and decrement v_i while k* does not drop and the band still holds.

Costs, in units of |M|: max = n*v_max/k*, avg = V/k*.  For theta = 2/3 the
allocation is the MiniCast main code.  The recovery code uses Capped Swiper at
theta = 1/3 with the same band and bound B.  Write A1 = V1/k1, A2 = V2/k2:

    max = max_i(n*v_i/k1 + A1*u_i/k2),   avg = A1*(1 + A2/n).

Each code separately has at most B fragments.  The recovery allocation is
computed even when only --theta 2/3 is selected; repeated settings are cached.
The protocol maximum is within the band of Balanced MiniCast: A1 <= n/nu_{2/3}
because one fragment per validator is always a candidate, and each allocation
separately satisfies its maximum-cost band.

Everything is exact: Fractions for s, p_i, c and the band; integers for v and
k*.  Standard library plus oracle.py (numpy optional, same results).

Usage:
    python3 allocate.py [NETWORK ... | all] [--theta 1/3 [2/3]] [--band 11/10 [1]]
                        [--bound 4 [2]] [--json FILE] [--check]

    --bound is a multiple of n (4 means V <= 4n).  Several values may be given
    for --theta, --band and --bound; every combination is run.  Defaults:
    all networks, both thetas, band 11/10, bound 4 (the paper's Table 2).
    --check compares each result with the record of allocations.json that it
    should reproduce (table2:*:4n for band 11/10 and bound 4, table2:*:4n:band1
    for band 1 and bound 4, text:*:2n for band 11/10 and bound 2) and exits
    non-zero on any difference.
    --json writes every result, including both MiniCast allocations, to FILE.
    The seconds column includes any recovery computation needed for that row.

Examples:
    python3 allocate.py --check
    python3 allocate.py Monad --theta 1/3 --band 11/10 --bound 4
    python3 allocate.py all --theta 1/3 2/3 --band 1 11/10 --bound 2 4
"""
import heapq
import json
import math
import os
import sys
import time
from fractions import Fraction as F

from oracle import Oracle, nu

HERE = os.path.dirname(os.path.abspath(__file__))
ORDER = ["Monad", "Kava", "Sui", "dYdX", "Sei", "Osmosis", "Injective", "Neutron"]


def scan(w, W, c, m, Vstop):
    """Swiper's scan: one fragment per step, ties in stakes.json order.

    Yields (v, i) after each step, where v is the current allocation and i the
    validator that just received a fragment.  m = None means no cap.
    """
    heap = [((1 - c) * W / F(wi), i) for i, wi in enumerate(w)
            if wi > 0 and (m is None or m >= 1)]
    heapq.heapify(heap)
    v = [0] * len(w)
    V = 0
    while heap and V < Vstop:
        s, i = heapq.heappop(heap)
        v[i] += 1
        V += 1
        if m is None or v[i] < m:
            heapq.heappush(heap, ((v[i] + 1 - c) * W / F(w[i]), i))
        yield v, i


def trim(w, v, nv, band, kstar):
    """Increasing stake order; decrement while k* does not drop and band holds."""
    v = list(v)
    ks0 = kstar(v)
    for i in sorted(range(len(v)), key=lambda j: (w[j], j)):
        while v[i] > 0:
            v[i] -= 1
            ks = kstar(v)
            if ks < ks0 or ks <= 0 or max(v) * nv > band * ks:
                v[i] += 1
                break
    return v


def procedure(w, theta, band, B, caps=None):
    """Capped Swiper for one (theta, band, B).  Returns a result dict."""
    n, W = len(w), sum(w)
    nv = nu(w, theta)
    O = Oracle(w, theta)
    c = 1 - theta
    Mcap = math.floor(band * B / nv)
    if caps is None:
        caps = list(range(1, Mcap + 1))
    cache = {}

    def kstar(v):
        key = tuple(v)
        ks = cache.get(key)
        if ks is None:
            ks = O.kstar(list(v))
            cache[key] = ks
        return ks

    cands = []
    for rank, m in enumerate(caps):
        vmax = 0
        V = 0
        for v, i in scan(w, W, c, m, B):
            V += 1
            if v[i] > vmax:
                vmax = v[i]
            ks = kstar(v)
            if ks >= 1 and vmax * nv <= band * ks:
                cands.append((F(V, ks), V, rank, m, tuple(v), ks))
                break
    ones = (1,) * n
    k1 = kstar(ones)
    assert k1 == nv and nv <= band * k1 and n <= B
    cands.append((F(n, k1), n, len(caps), "ones", ones, k1))
    win = min(cands, key=lambda z: (z[0], z[1], z[2]))
    vt = trim(w, win[4], nv, band, kstar)
    kt = kstar(vt)
    assert kt >= 1 and max(vt) * nv <= band * kt and sum(vt) <= B
    return dict(V=sum(vt), k=kt, vmax=max(vt), max=F(n * max(vt), kt),
                avg=F(sum(vt), kt), m=win[3], V_before_trim=win[1],
                k_before_trim=win[5], candidates=len(cands), v=vt)


def protocol(w, r, recovery):
    """Exact MiniCast costs from main and recovery allocations in input order."""
    n = len(w)
    a1 = F(r["V"], r["k"])
    a2 = F(recovery["V"], recovery["k"])
    mx = max(F(n * vi, r["k"]) + a1 * F(ui, recovery["k"])
             for vi, ui in zip(r["v"], recovery["v"]))
    av = a1 * (1 + a2 / n)
    return mx, av


def label_for(theta, band, mult):
    kind = "CT" if theta == F(1, 3) else "MiniCast"
    if band == F(11, 10) and mult == 4:
        return "table2:%s:4n" % kind
    if band == F(1) and mult == 4:
        return "table2:%s:4n:band1" % kind
    if band == F(11, 10) and mult == 2:
        return "text:%s:2n" % kind
    return None


def main(argv):
    args = list(argv)
    opts = {"--theta": ["1/3", "2/3"], "--band": ["11/10"], "--bound": ["4"]}
    jpath, check = None, False
    nets = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in opts:
            vals = []
            i += 1
            while i < len(args) and not args[i].startswith("--"):
                vals.append(args[i])
                i += 1
            opts[a] = vals
            continue
        if a == "--json":
            jpath = args[i + 1]
            i += 2
            continue
        if a == "--check":
            check = True
            i += 1
            continue
        if a in ("-h", "--help"):
            print(__doc__)
            return 0
        nets.append(a)
        i += 1
    stakes = json.load(open(os.path.join(HERE, "stakes.json")))
    if not nets or nets == ["all"]:
        nets = [x for x in ORDER if x in stakes]
    recs = json.load(open(os.path.join(HERE, "allocations.json"))) if check else []

    out, bad = [], 0
    computed = {}

    def allocation(net, th, band, mult):
        key = (net, th, band, mult)
        if key not in computed:
            computed[key] = procedure(stakes[net], th, band,
                                      mult * len(stakes[net]))
        return computed[key]

    def matches(net, th, band, mult, result):
        lab = label_for(th, band, mult)
        if lab is None:
            return None, "no record for this setting"
        hit = [x for x in recs if x["label"] == lab and
               x["network"] == net and F(x["theta"]) == th]
        ok = (len(hit) == 1 and hit[0]["v"] == result["v"] and
              hit[0]["k"] == result["k"])
        return ok, ("reproduces " if ok else "DIFFERS from ") + lab

    print("%-10s %-5s %-6s %-5s %5s %5s %5s %9s %8s %5s %5s %5s %9s %8s %8s  %s" % (
        "network", "theta", "band", "bound", "V", "k", "v_max", "max", "avg", "m",
        "V2", "k2", "prot.max", "prot.avg", "seconds", "check" if check else ""))
    for th_s in opts["--theta"]:
        th = F(th_s)
        for net in nets:
            w = stakes[net]
            n = len(w)
            for b_s in opts["--band"]:
                band = F(b_s)
                for mult_s in opts["--bound"]:
                    mult = int(mult_s)
                    t0 = time.time()
                    r = allocation(net, th, band, mult)
                    recovery = (allocation(net, F(1, 3), band, mult)
                                if th == F(2, 3) else None)
                    secs = time.time() - t0
                    pm, pa = (protocol(w, r, recovery) if recovery is not None
                              else (None, None))
                    if recovery is not None:
                        balanced = F(n, nu(w, th)) * (1 + F(1, nu(w, F(1, 3))))
                        assert r["avg"] <= F(n, nu(w, th))
                        assert pm <= band * balanced
                    status = ""
                    if check:
                        ok, status = matches(net, th, band, mult, r)
                        bad += (ok is False)
                        if recovery is not None:
                            ok2, status2 = matches(net, F(1, 3), band, mult, recovery)
                            bad += (ok2 is False)
                            status += "; recovery " + status2
                    print("%-10s %-5s %-6s %-5s %5d %5d %5d %9.3f %8.3f %5s %5s %5s %9s %8s %8.2f  %s" % (
                        net, th_s, b_s, "%dn" % mult, r["V"], r["k"], r["vmax"],
                        float(r["max"]), float(r["avg"]), r["m"],
                        "" if recovery is None else str(recovery["V"]),
                        "" if recovery is None else str(recovery["k"]),
                        "" if pm is None else "%.3f" % float(pm),
                        "" if pa is None else "%.3f" % float(pa), secs, status),
                          flush=True)
                    out.append(dict(network=net, theta=th_s, band=b_s,
                                    bound="%dn" % mult, V=r["V"], k=r["k"],
                                    vmax=r["vmax"], max=str(r["max"]),
                                    avg=str(r["avg"]), m=r["m"],
                                    V_before_trim=r["V_before_trim"],
                                    k_before_trim=r["k_before_trim"],
                                    seconds=round(secs, 3), v=r["v"]))
                    if recovery is not None:
                        out[-1].update(protocol_max=str(pm), protocol_avg=str(pa),
                                       recovery=dict(theta="1/3", V=recovery["V"],
                                                     k=recovery["k"], v=recovery["v"],
                                                     avg=str(recovery["avg"]),
                                                     max=str(recovery["max"])))
    if jpath:
        with open(jpath, "w") as fh:
            json.dump(out, fh)
    if check:
        print("\n%s" % ("all results reproduce allocations.json" if bad == 0 else
                        "%d result(s) do not reproduce allocations.json" % bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
