#!/usr/bin/env python3
"""Check every allocation in allocations.json against expected.json.

Standard library only; no solver, no third-party package, no floating point in
anything that decides feasibility.

For each record the largest valid reconstruction threshold is recomputed from
scratch:

    k*(v) = V - max{ v(T) : w(T) <= W - q },   q = floor(theta*W) + 1,

because a set S has stake greater than theta*W exactly when its complement T
has w(T) <= W - q.  The inner maximum is a 0/1 knapsack over ticket sums,
solved by dynamic programming in Python integers, so the check is exact for
stake values of any size.  A record is accepted only if k*(v) >= k.

Relay-upload cost, in units of |M|: max = n*v_max/k, avg = V/k.
For a MiniCast main code (theta = 2/3), the matching CT record (same network,
label suffix, band and fragment budget) supplies the recovery allocation:

    A1 = V1/k1, A2 = V2/k2,
    max = max_i(n*v_i/k1 + A1*u_i/k2), avg = A1*(1 + A2/n).

Both codes are checked separately for feasibility, fragment budget and band.
The whole-protocol maximum is also checked against the same band times the
Balanced MiniCast maximum.  Costs use the stated k, not a larger k*.

Each record is compared with the entry at the same position in expected.json
(label, network and theta must match; V exactly; max and avg to three
decimals).  It also recomputes |F|/n for each row of Table 2 (theta = 1/3 for CT,
2/3 for MiniCast), where validator i is in F when w_i plus the nu-1 heaviest
other stakes is at most theta*W, i.e. when i belongs to no set of nu validators
of stake greater than theta*W, and compares |F| and n with expected.json.
The pure 0% lemma bounds are recomputed exactly; the 10% LP bounds are checked
by bound.py, which needs an LP solver.

Usage:  python3 verify.py
Exit status 0 if everything agrees, 1 otherwise.
"""
import json
import os
import sys
from fractions import Fraction as F

HERE = os.path.dirname(os.path.abspath(__file__))
TOL = 0.0005 + 1e-9         # "agrees to three decimals"


def frac(theta):
    a, b = theta.split("/")
    return int(a), int(b)


def least_qualifying(w, theta):
    """q: the least stake that exceeds theta*W, in integers."""
    num, den = frac(theta)
    return (num * sum(w)) // den + 1


def nu(w, theta):
    """Fewest validators whose combined stake exceeds theta*W."""
    q = least_qualifying(w, theta)
    s = 0
    for k, x in enumerate(sorted(w, reverse=True), 1):
        s += x
        if s >= q:
            return k
    return len(w)


def kstar(v, w, theta):
    """Largest k with v(S) >= k for every S of stake greater than theta*W."""
    V = sum(v)
    cap = sum(w) - least_qualifying(w, theta)
    INF = None
    minw = [INF] * (V + 1)
    minw[0] = 0
    for vi, wi in zip(v, w):
        if vi <= 0 or vi > V:
            continue
        for t in range(V, vi - 1, -1):
            a = minw[t - vi]
            if a is not None and (minw[t] is None or a + wi < minw[t]):
                minw[t] = a + wi
    tmax = 0
    for t in range(V, -1, -1):
        if minw[t] is not None and minw[t] <= cap:
            tmax = t
            break
    return V - tmax


def free_set(w, theta):
    """|F|: validators i with w_i plus the nu-1 heaviest other stakes <= theta*W.

    Such a validator lies in no minimum-size qualifying set, so it is the only
    kind that can hold less than 1/nu when the maximum is optimal.
    """
    n = len(w)
    q = least_qualifying(w, theta)
    k = nu(w, theta)
    order = sorted(range(n), key=lambda i: -w[i])
    pref = [0]
    for i in order:
        pref.append(pref[-1] + w[i])
    rank = dict((i, r) for r, i in enumerate(order))
    out = []
    for i in range(n):
        heavy = pref[k - 1] if rank[i] >= k - 1 else pref[k] - w[i]
        if w[i] + heavy < q:
            out.append(i)
    return out


def main():
    stakes = json.load(open(os.path.join(HERE, "stakes.json")))
    recs = json.load(open(os.path.join(HERE, "allocations.json")))
    exp = json.load(open(os.path.join(HERE, "expected.json")))
    erecs = exp["records"]
    fails = []
    by_key = {}
    for r in recs:
        if r["label"].startswith("frontier:"):
            continue                         # several points share a frontier label
        key = (r["label"], r["network"], r["theta"])
        if key in by_key:
            fails.append("duplicate allocation record: %s" % (key,))
        by_key[key] = r
    if len(erecs) != len(recs):
        fails.append("allocations.json has %d records, expected.json %d"
                     % (len(recs), len(erecs)))

    print("=" * 96)
    print("allocations: %d records, %d stake distributions" % (len(recs), len(stakes)))
    print("=" * 96)
    print("%-20s %-10s %-5s %5s %5s %5s %5s %9s %9s  %-24s %s" % (
        "label", "network", "theta", "k", "V", "vmax", "k*", "max", "avg",
        "expected (max, avg, V)", ""))
    print("-" * 96)
    shown = {}
    for idx, r in enumerate(recs):
        e = erecs[idx] if idx < len(erecs) else None
        w = stakes[r["network"]]
        n = len(w)
        v = r["v"]
        tag = "%s %s %s" % (r["label"], r["network"], r["theta"])
        if len(v) != n or any(type(x) is not int or x < 0 for x in v):
            fails.append("%s: malformed allocation" % tag)
            continue
        V, vmax = sum(v), max(v)
        ks = kstar(v, w, r["theta"])
        if type(r["k"]) is not int or r["k"] < 1 or ks < r["k"]:
            fails.append("%s: k*=%d is below the stated k=%d" % (tag, ks, r["k"]))
            continue
        band = None
        if r["label"].startswith(("table2:", "benchmark:", "text:")):
            parts = r["label"].split(":")
            B = int(parts[2][:-1]) * n
            band = F(1) if parts[-1] == "band1" else F(11, 10)
            if V > B or vmax * nu(w, r["theta"]) > band * r["k"]:
                fails.append("%s: fragment budget or allocation band violated" % tag)
        if r["theta"] == "2/3":
            recovery_label = r["label"].replace(":MiniCast:", ":CT:")
            recovery = by_key.get((recovery_label, r["network"], "1/3"))
            if recovery is None:
                fails.append("%s: matching recovery allocation is missing" % tag)
                continue
            u, k2 = recovery["v"], recovery["k"]
            if (len(u) != n or any(type(x) is not int or x < 0 for x in u) or
                    type(k2) is not int or k2 < 1 or kstar(u, w, "1/3") < k2):
                fails.append("%s: invalid recovery allocation" % tag)
                continue
            if band is None or sum(u) > B or max(u) * nu(w, "1/3") > band * k2:
                fails.append("%s: recovery budget or band violated" % tag)
                continue
            a1, a2 = F(V, r["k"]), F(sum(u), k2)
            mx = max(F(n * vi, r["k"]) + a1 * F(ui, k2)
                     for vi, ui in zip(v, u))
            av = a1 * (1 + a2 / n)
            balanced = F(n, nu(w, "2/3")) * (1 + F(1, nu(w, "1/3")))
            if a1 > F(n, nu(w, "2/3")) or mx > band * balanced:
                fails.append("%s: whole-protocol maximum guarantee violated" % tag)
            if e is not None and (e.get("recovery_label") != recovery_label or
                                  e.get("V_recovery") != sum(u) or
                                  e.get("k_recovery") != k2):
                fails.append("%s: expected recovery metadata mismatch" % tag)
        else:
            mx = F(n * vmax, r["k"])
            av = F(V, r["k"])
        st = "ok"
        if e is None or (e["label"], e["network"], e["theta"]) != (
                r["label"], r["network"], r["theta"]):
            fails.append("%s: no matching entry in expected.json" % tag)
            st = "NO ENTRY"
        else:
            if V != e["V"]:
                fails.append("%s: V=%d, expected %d" % (tag, V, e["V"]))
                st = "MISMATCH"
            if abs(mx - e["max"]) > TOL:
                fails.append("%s: max %.4f, expected %.3f" % (tag, mx, e["max"]))
                st = "MISMATCH"
            if abs(av - e["avg"]) > TOL:
                fails.append("%s: avg %.4f, expected %.3f" % (tag, av, e["avg"]))
                st = "MISMATCH"
        group = r["label"]
        shown[group] = shown.get(group, 0) + 1
        if not group.startswith("frontier:front") or st != "ok":
            print("%-20s %-10s %-5s %5d %5d %5d %5d %9.3f %9.3f  %-24s %s" % (
                r["label"], r["network"], r["theta"], r["k"], V, vmax, ks, mx, av,
                "" if e is None else "%.3f, %.3f, %d" % (e["max"], e["avg"], e["V"]),
                st))
    for g in sorted(shown):
        if g.startswith("frontier:front"):
            print("(%d records labelled %s checked; listed only on a mismatch)"
                  % (shown[g], g))

    # |F|/n for each Table 2 row: theta = 1/3 for CT, 2/3 for MiniCast
    print("\n%-9s %-10s %-6s %5s %5s %5s %8s  %s" % (
        "protocol", "network", "theta", "n", "nu", "|F|", "|F|/n", "expected"))
    print("-" * 96)
    for kind, th in (("CT", "1/3"), ("MiniCast", "2/3")):
        for name in stakes:
            w = stakes[name]
            f = len(free_set(w, th))
            e = exp.get("free_fraction", {}).get(kind, {}).get(name)
            st = "(none)"
            if e is not None:
                ok = (f == e["F"] and len(w) == e["n"])
                st = "%d/%d %s" % (e["F"], e["n"], "ok" if ok else "MISMATCH")
                if not ok:
                    fails.append("|F|/n %s %s: got %d/%d, expected %d/%d"
                                 % (kind, name, f, len(w), e["F"], e["n"]))
            else:
                fails.append("|F|/n %s %s: no expected value" % (kind, name))
            print("%-9s %-10s %-6s %5d %5d %5d %7.1f%%  %s" % (
                kind, name, th, len(w), nu(w, th), f, 100.0 * f / len(w), st))

    print("\nPure 0% lemma bounds (no LP bound is substituted):")
    for name, w in stakes.items():
        n = len(w)
        l1 = F(n - len(free_set(w, "1/3")), nu(w, "1/3"))
        l2 = F(n - len(free_set(w, "2/3")), nu(w, "2/3"))
        for kind, val in (("CT", l1), ("MiniCast", l2 * (1 + l1 / n))):
            e = exp.get("lemma_bound", {}).get(kind, {}).get(name)
            if (e is None or F(e["exact"]) != val or
                    abs(float(val) - e["rounded"]) > TOL):
                fails.append("0%% lemma bound %s %s: mismatch" % (kind, name))
            print("%-9s %-10s %s = %.6f" % (kind, name, val, float(val)))

    inputs = exp.get("bound_inputs", {})
    half_width = F(inputs.get("rounding_half_width", "0.00005"))
    for name, w in stakes.items():
        try:
            l1 = F(inputs["1/3"][name])
            l2 = F(inputs["2/3"][name])
            lower = (l2 - half_width) * (1 + (l1 - half_width) / len(w))
            upper = (l2 + half_width) * (1 + (l1 + half_width) / len(w))
            e = exp["bound"]["MiniCast"][name]
            if round(float(lower), 3) != e or round(float(upper), 3) != e:
                fails.append("MiniCast LP bound %s: conversion is not precise to three decimals" % name)
        except (KeyError, ValueError):
            fails.append("MiniCast LP bound %s: missing or invalid source values" % name)
    print("MiniCast LP-bound decimal conversion checked; no LP solve performed.")

    print("\n" + "=" * 96)
    if fails:
        print("FAILED: %d mismatch(es)" % len(fails))
        for f in fails:
            print("  " + f)
        return 1
    print("OK: all %d records re-verified; every value matches expected.json "
          "(V exactly, max and avg to three decimals)" % len(recs))
    return 0


if __name__ == "__main__":
    sys.exit(main())
