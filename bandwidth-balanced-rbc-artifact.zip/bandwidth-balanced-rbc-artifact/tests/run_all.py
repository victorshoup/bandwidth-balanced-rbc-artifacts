"""Run every test script; --slow adds the live 64-setting comparison.

    python3 tests/run_all.py [--slow]

Exit status 0 when every test passes.
"""
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
FAST = ["test_oracle.py", "test_shaving.py", "test_procedure.py"]
SLOW = ["test_artifact.py"]


def main(argv):
    names = FAST + (SLOW if "--slow" in argv else [])
    bad = 0
    for name in names:
        t0 = time.perf_counter()
        rc = subprocess.call([sys.executable, os.path.join(HERE, name)])
        print("  %s: %s in %.1f s" % (name, "passed" if rc == 0 else "FAILED",
                                      time.perf_counter() - t0), flush=True)
        bad += rc != 0
    print("all tests passed" if bad == 0 else "%d test(s) failed" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
