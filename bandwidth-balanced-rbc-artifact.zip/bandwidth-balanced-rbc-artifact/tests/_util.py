"""Shared helpers for the tests: brute force by subset enumeration.

The tests are plain scripts (no pytest).  Run them from the artifact directory:

    python3 tests/run_all.py            # everything except the slow sweep
    python3 tests/run_all.py --slow     # also the live 64-setting comparison

With numpy installed, each test covers both the numpy and the pure-Python
backend; without it, only the pure-Python one.  TESTS_SCALE=k multiplies the
number of random instances.
"""
import os
import random
import sys
from fractions import Fraction as F
from itertools import combinations

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

import oracle                            # noqa: E402

SCALE = float(os.environ.get("TESTS_SCALE", "1"))
BACKENDS = [True] if oracle.np is None else [False, True]   # python=...
THETAS = [F(1, 3), F(2, 3), F(1, 2), F(1, 4), F(3, 5), F(5, 7)]


def reps(k):
    return max(1, int(k * SCALE))


def qof(w, theta):
    return (theta.numerator * sum(w)) // theta.denominator + 1


def subsets(n):
    for r in range(n + 1):
        for S in combinations(range(n), r):
            yield S


def kstar_brute(w, q, v):
    """min{ v(S) : w(S) >= q } by enumeration (None if nothing qualifies)."""
    best = None
    for S in subsets(len(w)):
        if sum(w[i] for i in S) >= q:
            c = sum(v[i] for i in S)
            if best is None or c < best:
                best = c
    return best


def mincost_brute(w, v, need, exclude):
    """min{ v(R) : exclude not in R, w(R) >= need }."""
    best = None
    items = [j for j in range(len(w)) if j != exclude]
    for r in range(len(items) + 1):
        for R in combinations(items, r):
            if sum(w[j] for j in R) >= need:
                c = sum(v[j] for j in R)
                if best is None or c < best:
                    best = c
    return best


def maxstake_brute(w, v, items, b):
    """max{ w(R) : R subset of items, v(R) <= b }."""
    best = 0
    for r in range(len(items) + 1):
        for R in combinations(items, r):
            if sum(v[j] for j in R) <= b:
                best = max(best, sum(w[j] for j in R))
    return best


def rand_stakes(rng, n, big=False):
    """Random stakes with ties, zeros and heavy validators mixed in."""
    kind = rng.choice(["uniform", "ties", "skew", "zeros", "whale"])
    hi = (1 << 80) if big else rng.choice([5, 20, 1000, 10 ** 6])
    if kind == "uniform":
        w = [rng.randint(1, hi) for _ in range(n)]
    elif kind == "ties":
        pool = [rng.randint(1, hi) for _ in range(rng.randint(1, 3))]
        w = [rng.choice(pool) for _ in range(n)]
    elif kind == "skew":
        w = [max(1, int(hi * rng.random() ** 4)) for _ in range(n)]
    elif kind == "zeros":
        w = [rng.choice([0, rng.randint(1, hi)]) for _ in range(n)]
        if sum(w) == 0:
            w[0] = 1
    else:
        w = [rng.randint(1, max(1, hi // 50)) for _ in range(n)]
        w[rng.randrange(n)] = hi
    return w


def check(cond, msg, *ctx):
    if not cond:
        raise AssertionError("%s  %r" % (msg, ctx))
