"""Shaving (trim) tests: prefix/suffix tables, safety test, trajectories.

Random small instances (n <= 9) with ties, zero stakes, positive-stake
validators holding zero fragments, validators whose own stake reaches q,
and equal-stake instances with many alternative minimum qualifying sets.
For each instance, with k0 = k*(v) >= 1 found by enumeration:

 1. Tables.  Every entry of every prefix table L (validators before i,
    final values) and suffix table R_i (validators after i, values before
    the trim) that trim_fast actually uses equals the brute-force maximum
    stake at fragment cost <= b, for b = 0..k0-1.
 2. Safety test.  For every validator i with v_i > 0 and every t with
    0 <= t <= v_i (current state), the prefix/suffix test "C < 0 or
    w_i + F_i(C) < q", C = k0-1-t, agrees with k*(v with v_i = t) = k0
    computed by enumeration.
 3. Endpoint.  The value chosen for i equals max(0, k0 - r_i) with r_i by
    enumeration (the forced-inclusion formulation).
 4. Trajectory.  The allocation after each validator equals the state of
    the reference repeated-decrement loop (trim_reference driven by the
    brute-force k*) after the same validator, for shave = split / direct,
    tight = False / "seed" / True, check = False / True.  The reference
    loop's final vector equals allocate_reference.trim, its trial count
    equals the optimized counter trim_reference_trials, and the optimized
    split path runs no k* DP at all.
"""
import random
from fractions import Fraction as F

from _util import (BACKENDS, THETAS, check, kstar_brute, maxstake_brute,
                   mincost_brute, rand_stakes, reps, qof)
import allocate
import allocate_reference
from oracle import Oracle, TicketOracle, nu

OPTS = [dict(shave=s, tight=t, check=c)
        for s in ("split", "direct")
        for t in (False, "seed", True)
        for c in (False, True)]


def instance(rng):
    n = rng.randint(1, 9)
    kind = rng.random()
    if kind < 0.15:                          # all equal: many minimum sets
        w = [rng.randint(1, 9)] * n
    else:
        w = rand_stakes(rng, n)
    theta = rng.choice(THETAS)
    v = [rng.choice([0, 0, 1, 1, 2, 3, 4]) for _ in range(n)]
    return w, theta, v


def run_case(w, theta, v, python, counts):
    n = len(w)
    q = qof(w, theta)
    k0 = kstar_brute(w, q, v)
    if not k0:                               # k* = 0 or nothing qualifies
        return False
    O = TicketOracle(w, theta, python=python)
    nv = nu(w, theta)
    band = F(max(v) * nv, k0)                # the start is exactly in band
    order = sorted(range(n), key=lambda j: (w[j], j))
    vorig = list(v)

    def kb(x):
        return kstar_brute(w, q, x)

    # reference trajectory, driven by brute-force k*
    ref_states = []
    st_ref = allocate.new_stats()
    vref = allocate.trim_reference(w, v, nv, band, kb, st_ref,
                                   trace=lambda i, x: ref_states.append((i, x)))
    check(vref == allocate_reference.trim(w, v, nv, band, kb),
          "trim_reference differs from allocate_reference.trim", w, v)
    counts["reference_trials"] += st_ref["trim_reference_trials"]

    seed = O.kstar_upto(v, k0)[1]
    check(seed is not None and sum(v[j] for j in seed) == k0, "seed")

    for opt0 in OPTS:
        opt = dict(allocate.DEFAULT_OPTS, **opt0)
        st = allocate.new_stats()
        states = []
        probed = []

        def probe(p, i, vcur, pre, suf):
            probed.append(i)
            check(vcur[:0] == [] and order[p] == i, "probe order")
            before, after = order[:p], order[p + 1:]
            for b in range(k0):
                counts["table_entries"] += 2
                check(int(pre[b]) == maxstake_brute(w, vcur, before, b),
                      "prefix table", w, v, p, b)
                check(int(suf[b]) == maxstake_brute(w, vorig, after, b),
                      "suffix table", w, v, p, b)
            check(all(vcur[j] == vorig[j] for j in after + [i]),
                  "suffix/current values changed early")
            if vcur[i] > 0:
                r = mincost_brute(w, vcur, q - w[i], i)
                for t in range(vcur[i] + 1):
                    C = k0 - 1 - t
                    if C < 0:
                        test = True
                    else:
                        F_i = max(int(pre[a]) + int(suf[C - a])
                                  for a in range(C + 1))
                        test = w[i] + F_i < q
                    x = list(vcur)
                    x[i] = t
                    counts["safety_tests"] += 1
                    check(test == (kb(x) == k0), "safety test", w, v, i, t)
                # the endpoint the loop reaches
                expect = 0 if r is None else max(0, k0 - r)
                endpoints[i] = expect

        endpoints = {}
        seeds = [seed] if opt["tight"] else []
        vt = allocate.trim_fast(O, v, nv, band, k0, seeds, opt, st,
                                trace=lambda i, x: states.append((i, x)),
                                kcheck=lambda x: kb(x), probe=probe)
        check(states == ref_states, "trajectory", w, v, opt0,
              states, ref_states)
        check(vt == vref, "final vector", w, v, opt0)
        for i, e in endpoints.items():
            got = dict(states)[i][i]
            check(got == e, "endpoint vs forced-inclusion formula",
                  w, v, i, got, e)
            counts["endpoints"] += 1
        check(st["trim_reference_trials"] == st_ref["trim_reference_trials"],
              "trial count", w, v, opt0)
        check(st["trim_fragments_removed"] == sum(vorig) - sum(vt),
              "fragments removed")
        if opt["shave"] == "split":
            check(probed == order, "every validator probed")
            check(st["trim_forced_dp"] == 0 and st["full_kstar_trim"] == 0,
                  "split must run no DP")
            check(st["trim_suffix_updates"] == n and
                  st["trim_prefix_updates"] == n, "table updates")
        if opt["check"]:
            check(st["trim_check_kstar"] == n, "debug k* checks")
        counts["trajectories"] += 1
    return True


def crafted():
    """Hand-made cases for the edge conditions named in the report."""
    T = F(2, 3)
    return [
        ([5, 5, 5, 5, 5, 5], T, [1, 1, 1, 1, 1, 1]),    # many tight sets
        ([1, 1, 1, 30], T, [0, 2, 1, 3]),               # w_i >= q alone
        ([3, 4, 0, 6, 7], T, [2, 0, 3, 1, 2]),          # zero fragments, w > 0
        ([3, 4, 0, 6, 7], T, [0, 0, 0, 1, 2]),          # free stake
        ([2, 2, 2, 9, 9], F(1, 3), [4, 0, 1, 2, 3]),
        ([1, 2, 3, 4, 5, 6, 7], F(1, 2), [3, 3, 3, 3, 3, 3, 3]),
        ([7], T, [3]),                                  # n = 1
        ([0, 0, 4], T, [2, 1, 1]),                      # zero stakes
        ([1, 1, 1, 1], F(1, 4), [1, 2, 3, 4]),
    ]


def main():
    rng = random.Random(7)
    counts = dict(instances=0, trajectories=0, table_entries=0,
                  safety_tests=0, endpoints=0, reference_trials=0)
    for python in BACKENDS:
        for w, theta, v in crafted():
            check(run_case(w, theta, v, python, counts), "crafted case", w, v)
            counts["instances"] += 1
        done = 0
        while done < reps(400):
            w, theta, v = instance(rng)
            if run_case(w, theta, v, python, counts):
                done += 1
                counts["instances"] += 1
    print("test_shaving: OK", counts)


if __name__ == "__main__":
    main()
