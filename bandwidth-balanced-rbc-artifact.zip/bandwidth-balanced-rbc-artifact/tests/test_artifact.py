"""Live comparison on the artifact's 64-setting sweep (slow: runs the reference).

All eight networks x theta in {1/3, 2/3} x band in {1, 11/10} x bound in
{2n, 4n}.  For each setting, allocate_reference.procedure (untouched; spies
on its min and trim capture the candidate list and the pre-trim vector) is
compared with allocate.procedure on both backends:

  * every result field: v, V, k, vmax, max, avg, m, V_before_trim,
    k_before_trim, candidates; for theta = 2/3 also the paired recovery
    allocation and the protocol max/avg (allocate_reference.protocol vs
    allocate.protocol);
  * the per-cap candidate list, the winner and the pre-trim vector;
  * the state after EACH validator of the trim: the reference loop
    (trim_reference, identical to allocate_reference.trim, driven by the
    exact Oracle.kstar) against trim_fast with shave = split / direct and
    tight = False / "seed" / True;
  * the optimized split trim runs no k* DP.

Usage: python3 tests/test_artifact.py [--json FILE]  (FILE: per-setting log)
"""
import json
import os
import sys
import time
from fractions import Fraction as F

from _util import BACKENDS, ROOT, check
import allocate
import allocate_reference as ref
from oracle import Oracle, TicketOracle, nu

captured = {}
_min, _trim = min, ref.trim


def spy_min(cands, key):
    captured["cands"] = list(cands)
    return _min(cands, key=key)


def spy_trim(w, v, nv, band, kstar):
    captured["pre_trim"] = tuple(v)
    return _trim(w, v, nv, band, kstar)


ref.min = spy_min
ref.trim = spy_trim

TRIM_OPTS = [dict(shave=s, tight=t) for s in ("split", "direct")
             for t in (False, "seed", True)]


def main(argv):
    jpath = argv[argv.index("--json") + 1] if "--json" in argv else None
    stakes = json.load(open(os.path.join(ROOT, "stakes.json")))
    settings = [(net, th, band, mult)
                for th in (F(1, 3), F(2, 3)) for net in allocate.ORDER
                for band in (F(1), F(11, 10)) for mult in (2, 4)]
    want, got = {}, {}
    log = []
    counts = dict(settings=0, fields=0, candidates=0, trim_states=0,
                  trajectories=0, reference_seconds=0.0)
    for key in settings:
        net, th, band, mult = key
        w = stakes[net]
        n = len(w)
        captured.clear()
        t0 = time.perf_counter()
        want[key] = ref.procedure(w, th, band, mult * n)
        counts["reference_seconds"] += time.perf_counter() - t0
        rc, pre = captured["cands"], captured["pre_trim"]
        win = _min(rc, key=lambda z: (z[0], z[1], z[2]))
        # reference trim trajectory, by the reference loop and exact k*
        full = Oracle(w, th)
        cache = {}

        def kstar(v):
            t = tuple(v)
            if t not in cache:
                cache[t] = full.kstar(list(v))
            return cache[t]

        nv = nu(w, th)
        ref_states = []
        vref = allocate.trim_reference(
            w, pre, nv, band, kstar,
            trace=lambda i, x: ref_states.append((i, x)))
        check(vref == want[key]["v"], "reference trim copy", key)
        for python in BACKENDS:
            st = {}
            r = allocate.procedure(w, th, band, mult * n, stats=st,
                                   python=python)
            check(r == want[key], "result dict", key, python)
            counts["fields"] += len(r)
            check([tuple(z) for z in st["cands"]] == [tuple(z) for z in rc],
                  "candidates", key, python)
            check(tuple(st["winner"]) == tuple(win), "winner", key)
            check(tuple(st["winner"][4]) == pre, "pre-trim vector", key)
            check(st["full_kstar_trim"] == 0 and st["trim_forced_dp"] == 0,
                  "split trim ran a DP", key)
            counts["candidates"] += len(rc)
            got[(key, python)] = r
            O = TicketOracle(w, th, python=python)
            k0 = win[5]
            seed = O.kstar_upto(list(pre), k0)[1]
            for o in TRIM_OPTS:
                opt = dict(allocate.DEFAULT_OPTS, **o)
                states = []
                vt = allocate.trim_fast(
                    O, pre, nv, band, k0, [seed] if o["tight"] else [], opt,
                    allocate.new_stats(),
                    trace=lambda i, x: states.append((i, x)))
                check(states == ref_states, "trim trajectory", key, o, python)
                check(vt == vref, "trimmed vector", key, o)
                counts["trim_states"] += len(states)
                counts["trajectories"] += 1
        entry = dict(network=net, theta=str(th), band=str(band),
                     bound="%dn" % mult, V=want[key]["V"], k=want[key]["k"],
                     candidates=len(rc), validators=n,
                     trimmed=want[key]["V_before_trim"] - want[key]["V"],
                     match=True)
        if th == F(2, 3):
            rk = (net, F(1, 3), band, mult)
            pw = ref.protocol(w, want[key], want[rk])
            for python in BACKENDS:
                pg = allocate.protocol(w, got[(key, python)],
                                       got[(rk, python)])
                check(pg == pw, "protocol costs", key, python)
                check(got[(rk, python)] == want[rk], "recovery", key)
            entry.update(protocol_max=str(pw[0]), protocol_avg=str(pw[1]))
        log.append(entry)
        counts["settings"] += 1
        print("  %-9s %-3s %-5s %2dn  ok" % (net, th, band, mult), flush=True)
    counts["reference_seconds"] = round(counts["reference_seconds"], 1)
    if jpath:
        with open(jpath, "w") as fh:
            json.dump(dict(counts=counts, backends=["python" if p else "numpy"
                                                    for p in BACKENDS],
                           settings=log), fh, indent=1)
    print("test_artifact: OK", counts)


if __name__ == "__main__":
    main(sys.argv[1:])
