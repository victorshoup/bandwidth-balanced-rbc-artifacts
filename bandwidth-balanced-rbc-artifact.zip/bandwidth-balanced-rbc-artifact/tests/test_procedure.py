"""Randomized end-to-end differential test against allocate_reference.

Small random instances (n <= 16) vary the stakes (ties, zeros, whales),
theta, band >= 1 (the reference asserts nu <= band * nu for the all-ones
candidate), the bound B in [n, 4n] and the caps: default, a consecutive
prefix 1..r (r may exceed the default range), or a non-consecutive list
(which falls back to the reference).  A second batch uses artifact-like
settings (n = 20..40, skewed stakes, theta 1/3 or 2/3, band 1 or 11/10,
B = 2n or 4n), where trimming removes fragments far more often.  For each instance:

  * the complete result dict of allocate.procedure equals that of
    allocate_reference.procedure, on both backends and for the default
    options plus random combinations of every switch;
  * the per-cap candidate list, the winner and the pre-trim vector equal
    the reference's, captured by spies on allocate_reference.min and
    allocate_reference.trim (the reference code itself is untouched).
"""
import random
from fractions import Fraction as F

from _util import BACKENDS, THETAS, check, rand_stakes, reps
import allocate
import allocate_reference as ref
from oracle import nu

SWITCHES = dict(bisect=(True, False), bounded=(True, False),
                witness=(True, False), shave=("split", "direct", "reference"),
                tight=(False, "seed", True), check=(False, True))
BANDS = [F(1), F(11, 10), F(5, 4), F(3, 2), F(2)]

captured = {}
_min, _trim = min, ref.trim


def spy_min(cands, key):
    captured["cands"] = list(cands)
    return _min(cands, key=key)


def spy_trim(w, v, nv, band, kstar):
    captured["pre_trim"] = tuple(v)
    return _trim(w, v, nv, band, kstar)


ref.min = spy_min                        # module globals shadow the builtins
ref.trim = spy_trim


def main():
    rng = random.Random(11)
    counts = dict(instances=0, runs=0, fallbacks=0, candidates=0,
                  cap_winner=0, trimmed=0, probes=0, witness_skips=0)
    small, large = reps(500), reps(80)
    for it in range(small + large):
        if it < small:
            n = rng.randint(1, 16)
            w = rand_stakes(rng, n)
            theta = rng.choice(THETAS)
            band = rng.choice(BANDS)
            B = rng.randint(n, 4 * n)
        else:                                # artifact-like settings
            n = rng.randint(20, 40)
            w = [max(1, int(10 ** 6 * rng.random() ** rng.choice([2, 4, 8])))
                 for _ in range(n)]
            theta = rng.choice([F(1, 3), F(2, 3)])
            band = rng.choice([F(1), F(11, 10)])
            B = rng.choice([2, 4]) * n
        Mcap = int(band * B / nu(w, theta))
        u = rng.random()
        if u < 0.6:
            caps = None
        elif u < 0.8:
            caps = list(range(1, rng.randint(1, Mcap + 3) + 1))
        else:
            caps = sorted(rng.sample(range(1, Mcap + 3),
                                     rng.randint(1, min(3, Mcap + 2))))
        captured.clear()
        want = ref.procedure(w, theta, band, B, caps)
        rc, pre = captured.get("cands"), captured.get("pre_trim")
        counts["cap_winner"] += want["m"] != "ones"
        counts["trimmed"] += want["V"] < want["V_before_trim"]
        consecutive = caps is None or caps == list(range(1, len(caps) + 1))
        combos = [{}] + [{k: rng.choice(v) for k, v in SWITCHES.items()}
                         for _ in range(4)]
        for python in BACKENDS:
            for opts in combos:
                captured.clear()
                st = {}
                got = allocate.procedure(w, theta, band, B, caps, stats=st,
                                         opts=opts, python=python)
                ctx = (w, theta, band, B, caps, opts, python)
                check(got == want, "result dict", ctx, got, want)
                if consecutive:
                    mine = [tuple(z) for z in st["cands"]]
                    check(mine == [tuple(z) for z in rc], "candidates", ctx)
                    win = _min(rc, key=lambda z: (z[0], z[1], z[2]))
                    check(tuple(st["winner"]) == tuple(win), "winner", ctx)
                    check(tuple(st["winner"][4]) == pre, "pre-trim", ctx)
                    counts["candidates"] += len(mine)
                    counts["probes"] += st["probes"]
                    counts["witness_skips"] += st["witness_states_skipped"]
                else:
                    counts["fallbacks"] += 1
                counts["runs"] += 1
        counts["instances"] += 1
    print("test_procedure: OK", counts)


if __name__ == "__main__":
    main()
