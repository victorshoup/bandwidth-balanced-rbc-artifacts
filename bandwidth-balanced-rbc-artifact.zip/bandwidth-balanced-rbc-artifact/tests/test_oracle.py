"""TicketOracle (bounded DP) against Oracle.kstar and brute-force enumeration.

For random (w, theta, v, U), on both backends:
  * kstar_upto(v, U) returns (k*, S) with S qualifying and v(S) = k* exactly
    when k* <= U, and (None, None) exactly when k* > U;
  * violating(v, k) returns a qualifying S with v(S) < k, or None exactly
    when k* >= k;
  * forced_cost(v, i, U) returns r_i = min{ v(R) : i not in R,
    w(R) >= q - w_i } with a witness R when r_i <= U, else None.
Stakes include ties, zeros and values above 2^62 (Python-integer path).
Also: Oracle, nu and seed_sets in oracle.py (used by allocate_reference.py
and bound.py) are source-identical to oracle_reference.py, the supplied
oracle.py.
"""
import inspect
import random
from fractions import Fraction as F

from _util import (BACKENDS, THETAS, check, kstar_brute, mincost_brute,
                   rand_stakes, reps, qof)
import oracle
import oracle_reference
from oracle import Oracle, TicketOracle


def one(rng, n, big, python, counts):
    w = rand_stakes(rng, n, big)
    theta = rng.choice(THETAS)
    q = qof(w, theta)
    v = [rng.choice([0, 0, 1, 1, 2, 3, 5]) for _ in range(n)]
    O = TicketOracle(w, theta, python=python)
    check(O.q == q, "q")
    kb = kstar_brute(w, q, v)
    check(kb == Oracle(w, theta).kstar(v), "Oracle.kstar vs brute", w, v)
    V = sum(v)
    for U in sorted({0, 1, max(0, kb - 1), kb, kb + 1, V, rng.randint(0, V + 2)}):
        k, S = O.kstar_upto(v, U)
        counts["kstar_upto"] += 1
        if kb <= U:
            check(k == kb, "k*", w, v, U, k, kb)
            check(len(set(S)) == len(S), "duplicate in S", S)
            check(sum(w[i] for i in S) >= q, "S qualifies", w, v, S)
            check(sum(v[i] for i in S) == kb, "v(S) = k*", w, v, S)
        else:
            check(k is None and S is None, "claimed k* <= U", w, v, U, k)
    for k in range(0, V + 2):
        S = O.violating(v, k)
        counts["violating"] += 1
        if S is None:
            check(kb >= k, "violating missed", w, v, k)
        else:
            check(sum(w[i] for i in S) >= q and sum(v[i] for i in S) < k,
                  "bad violating witness", w, v, k, S)
    for i in range(n):
        rb = mincost_brute(w, v, q - w[i], i)
        for U in sorted({0, V, max(0, (rb or 0) - 1), rb or 0}):
            r, R = O.forced_cost(v, i, U)
            counts["forced_cost"] += 1
            if rb is not None and rb <= U:
                check(r == rb, "r_i", w, v, i, U, r, rb)
                check(i not in R and sum(w[j] for j in R) >= q - w[i] and
                      sum(v[j] for j in R) == rb, "forced witness", w, v, i, R)
            else:
                check(r is None and R is None, "r_i claimed", w, v, i, U, r)


def main():
    rng = random.Random(20260921)
    counts = dict(instances=0, kstar_upto=0, violating=0, forced_cost=0)
    for python in BACKENDS:
        for _ in range(reps(600)):
            n = rng.randint(1, 9)
            one(rng, n, rng.random() < 0.2, python, counts)
            counts["instances"] += 1
    # the two-limb / Python-integer path must be chosen above 2^62
    w = [(1 << 70) + 3, (1 << 70) + 3, 5, (1 << 62)]
    O = TicketOracle(w, F(2, 3))
    check(not O.use_np, "big stakes use Python integers")
    for name in ("Oracle", "nu", "seed_sets"):
        check(inspect.getsource(getattr(oracle, name)) ==
              inspect.getsource(getattr(oracle_reference, name)),
              "oracle.%s differs from the supplied code" % name)
    print("test_oracle: OK", counts)


if __name__ == "__main__":
    main()
