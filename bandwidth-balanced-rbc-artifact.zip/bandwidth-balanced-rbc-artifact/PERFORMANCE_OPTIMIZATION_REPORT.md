# Performance optimization of Capped Swiper (`allocate.py`)

## 1. Summary

`allocate.py` computes exactly the same allocations as before, much faster. The optimized code reproduces the original implementation (kept as `allocate_reference.py`) on every output field, every per-cap candidate, the winner, the pre-trim vector, and the allocation after every validator's turn in the trim. This holds for all 64 benchmark settings, on both backends, and on thousands of random instances. `allocations.json` and `expected.json` are unchanged; `verify.py` and both `--check` commands pass.

| workload | reference, numpy | optimized, numpy | speedup | reference, pure Python | optimized, pure Python | speedup |
|---|---|---|---|---|---|---|
| A: Monad, eight settings | 34.8 s | 36.5 ms | 956× | 299.9 s | 199 ms | 1506× |
| B: Monad MiniCast pair (θ 2/3 + 1/3, band 11/10, 4n) | 14.8 s | 15.2 ms | 974× | 140.0 s | 103 ms | 1365× |
| C: B's main code (θ = 2/3) | 2718 ms | 4.46 ms | 609× | 22.2 s | 52.0 ms | 426× |
| C: B's recovery code (θ = 1/3) | 12.1 s | 10.4 ms | 1166× | 118.3 s | 51.1 ms | 2317× |
| D: all 64 settings | 46.6 s | 171 ms | 273× | 338.2 s | 449 ms | 753× |

Medians, one thread, in-process `procedure` calls (plus `protocol` for B). The reference is 1–3 runs per entry (numpy: 3 for B and C, 1 for A, 1 for D; pure Python: 1 each). §7 has the minima, quartiles, cold-start times, shaving-only times and the ablation.

The ordinary two-code MiniCast allocation for Monad (θ = 2/3 main + θ = 1/3 recovery, band 11/10, V ≤ 4n) takes 15.2 ms in-process with numpy, against 14.8 s for the reference. A fresh `python3 allocate.py Monad --theta 2/3 --band 11/10 --bound 4` process takes 69 ms wall-clock with numpy; 48 ms of that is interpreter start-up and imports.

## 2. Environment

- Machine: ASRock Rack B650D4U-2L2T/BCM (server motherboard, bare metal; systemd-detect-virt: none)
- CPU: AMD Ryzen 9 7950X 16-Core Processor (Zen 4), x86_64; 16 cores, 1 thread per core (SMT off), 1 socket
- Caches: L1d 32 KiB + L1i 32 KiB per core, L2 1 MiB per core, L3 64 MiB (2 x 32 MiB)
- Clock: acpi-cpufreq, governor 'userspace', fixed 4.5 GHz (scaling_setspeed 4500000 kHz), boost disabled; rated max 5.88 GHz. With a fixed clock and no turbo, run-to-run variation is small (see the IQRs)
- Memory: 128 GB (MemTotal 124.8 GiB)
- OS: Ubuntu 25.10, Linux kernel 6.17.0-41-generic
- Python 3.13.7. numpy 2.5.3 in a venv (`venv-np`). The system `python3` (same version) has no numpy and runs the pure-Python path
- numpy active for the optimized code in the "numpy" columns: yes (except dYdX and Injective, whose stakes exceed 2^62: Python integers). The "pure Python" columns ran under the system `python3` without numpy, for both the reference and the optimized code

All timings use one thread on one dedicated physical core (`taskset -c N`; SMT is off, so no sibling thread shares it; `OMP_NUM_THREADS=OPENBLAS_NUM_THREADS=MKL_NUM_THREADS=1`) and `time.perf_counter_ns()`. Fast workloads are repeated (reps listed in `results/timings.json`) and given as median, minimum and interquartile range; reference timings are 1–3 runs. The numpy and pure-Python benchmark runs were pinned to two different physical cores and ran concurrently. "numpy" means the optimized code ran with numpy available. The reference always used the exact `Oracle` (numpy when available). dYdX and Injective have stakes above 2^62, so the optimized code uses Python integers for them even when numpy is present.

## 3. What was slow

For each cap m = 1..⌊band·B/ν⌋, the reference (`allocate_reference.py`) steps through the Swiper family one fragment at a time. At every state it calls the full exact oracle `Oracle.kstar`, a knapsack DP over all V + 1 ticket sums, until the first state within the band. It memoizes by state, but consecutive states always differ, so nearly every state costs one full DP. Monad's recovery code (θ = 1/3) at band 11/10, 4n has 38 caps, and many of them walk hundreds of states that can never be accepted. The trim then decrements one fragment at a time and runs one full DP per trial. §8 gives the counts: 132,370 full DPs for the 64 settings.

## 4. The optimizations and why they are exact

Notation: stakes w_i ≥ 0 (integers), W = Σw_i > 0, q = ⌊θW⌋ + 1, so S *qualifies* iff w(S) ≥ q (⇔ w(S) > θW). k\*(v) = min{v(S) : S qualifies}. ν = ν_θ; band b = p/r in lowest terms; c = 1 − θ ∈ (0, 1).

### 4.1 Breakpoints with exact integer keys

The reference's heap pops pairs (i, j) (validator i receiving its j-th fragment) in order of the key (s, i), with s = (j − c)·W/w_i an exact Fraction. Writing c = cn/cd, s = (j·cd − cn)·W/(cd·w_i), a positive multiple of x = (j·cd − cn)/w_i, so the order is that of (x, i). Two distinct such rationals differ by at least 1/(w_i·w_k) > 2^(−2·maxbits). Hence, with K = 2·maxbits + 1, ⌊x·2^K⌋ = ((j·cd − cn) ≪ K) // w_i preserves strict order (the scaled values differ by more than 2) and equality. One global list of all pairs, sorted by (⌊x·2^K⌋, i, j), therefore gives the scan order of every cap. The cap-m sequence is the subsequence with j ≤ m, because pairs with j > m are never pushed. Validators with w_i = 0 never receive a fragment and are excluded, as in the reference.

### 4.2 Cap recursion and binary search on each cap's suffix

This is the argument reviewed in the previous session (by the author and by ChatGPT), restated.

*Setup.* P = {i : w_i > 0}. s^m_t is the allocation after the first t pairs of the cap-m sequence. The reference examines t = 1..T_m, with T_m = min(B, |P|·m), and accepts the first t with ACC(v): k\*(v) ≥ 1 and v_max·ν ≤ b·k\*(v). ACC depends only on v.

**Lemma 1 (the heaviest validator holds the maximum).** Let h be the heaviest validator, the smallest index among ties. Then v_max(s^m_t) = s^m_t[h] for all m, t.
*Proof.* For i ∈ P, i ≠ h and 1 ≤ j ≤ m: j − c > 0 and w_i ≤ w_h give (j − c)W/w_h ≤ (j − c)W/w_i. Equality forces w_i = w_h and then h < i, so key(h, j) < key(i, j). Whenever (i, j) is among the first t pairs, so is (h, j). ∎

Let a_m be the position of (h, m) in the cap-m sequence, the first pair with j = m.

**Lemma 2 (shared prefix).** For m ≥ 2 and t ≤ a_m − 1: s^m_t = s^{m−1}_t. *Proof.* Deleting the j = m pairs from the cap-m sequence leaves the cap-(m−1) sequence in the same order, and the first a_m − 1 pairs contain none. ∎ (Also a_m − 1 ≤ |P|(m − 1).)

**Lemma 3 (fixed requirement on the suffix).** For a_m ≤ t ≤ T_m, v_max = m, so ACC(s^m_t) ⇔ k\*(s^m_t) ≥ K_m := max(1, ⌈m·ν·r/p⌉), in integer arithmetic.

**Lemma 4 (monotonicity).** s^m_t ≤ s^m_{t+1} pointwise, and k\* is monotone in v. So on [a_m, T_m] the predicate k\*(s^m_t) ≥ K_m runs False…False True…True, and binary search finds its first True.

**Theorem.** Let first(m) be the reference's accepted t for cap m, or none. For m = 1, a_1 = 1 and first(1) is found by binary search on [1, T_1]. For m ≥ 2:
(a) if first(m−1) = t′ < a_m, then first(m) = t′ (Lemma 2: identical states, and ACC depends only on the state);
(b) otherwise, if a_m > T_m, then first(m) = none: every examined state lies before a_m, so it is a cap-(m−1) state that cap m−1 examined and rejected;
(c) otherwise, states 1..a_m − 1 were rejected under cap m−1 for the same reason, and first(m) is the binary search on [a_m, T_m]. ∎

The recursion needs the caps in the order 1, 2, …, M. Any other `caps` list falls back to the reference. Before a_m the predicate is **not** monotone (v_max rises with h's fragments). Neutron shows this in 11 of 12 caps, so the search is confined to the suffix.

**The returned k\* is exact.** At the first accepted state t, k\*(s^m_t) = K_m. If t > a_m, state t − 1 was rejected, so k\* ≤ K_m − 1 there, and one fragment raises k\* by at most 1. If t = a_m and m ≥ 2, state a_m − 1 was rejected under cap m−1 with v_max = m − 1 (Lemma 1). So either its k\* = 0, or (m − 1)ν > b·k\*, which gives k\* < mν/b and hence k\* ≤ K_m − 1. If t = a_1 = 1, the previous state is the zero vector, with k\* = 0. The code keeps a fallback for k\* > K_m (`full_kstar_scan`), and it never ran.

### 4.3 Bounded decision DP (`oracle.TicketOracle`)

To decide k\*(v) ≥ K it is enough to know whether some qualifying set has v(S) ≤ K − 1. `TicketOracle.min_cost(v, need, U, exclude)` runs a 0/1 knapsack over fragment cost 0..U that maximizes stake:

best[t] = max{w(S) : v(S) ≤ t},  so  k\*(v) = min{t : best[t] ≥ q}.

- Validators with v_i = 0 cost nothing; their stake is added once, up front.
- Validators with v_i > U cannot be in a set of cost ≤ U.
- Validators of equal cost c form a group. Among equal-cost items, the best k of them are the k heaviest (an exchange argument), so a group turns best[] into max_k best[t − kc] + (sum of the k heaviest).

One run with U = K_m decides the probe and, when k\* ≤ U, returns k\* and an explicit qualifying set S with v(S) = k\*. The same run gives both the decision and the witness. Arithmetic is numpy int64 when W < 2^62 (every stake sum fits); otherwise, or without numpy, it uses Python integers. Tests compare it with `Oracle.kstar` and with enumeration (§6). The original `Oracle`, `nu` and `seed_sets` are unchanged, and a test checks that they are source-identical to the supplied `oracle.py`, because `bound.py` imports them.

### 4.4 Witness guards

A set S that qualifies does so independently of v. If S failed a probe (v(S) < K_m), then every later state with v(S) < K_m also fails, since k\* ≤ v(S). Along the scan, v(S) is nondecreasing, so a cumulative sum over the suffix's events gives the first state at which v(S) ≥ K_m, and every state before it can be skipped without a DP. The most recent 16 witnesses are kept across caps. Skipping only states that are proved to fail cannot change the first accepted state.

### 4.5 Shaving: prefix/suffix DP reuse

This is the trim method specified in the latest instructions. §9 says how it relates to the earlier code.

**Reference semantics.** Let v⁰ be the winner and k0 = k\*(v⁰). Validators are visited in increasing (w_i, i), positions p = 0..n−1. For each one, v_i is decremented while the trial state has k\* ≥ k0, k\* > 0 and v_max·ν ≤ b·k\*. A failed trial is undone and the loop moves to the next validator.

**Lemma S1 (only k\* matters).** Every accepted state has k\* = k0, and a trial is accepted iff its k\* ≥ k0 (equivalently = k0).
*Proof.* Decrements cannot raise k\*, so an accepted trial has k\* = k0 exactly. k0 ≥ 1: a cap candidate satisfies ACC, and the all-ones candidate has k\* = ν ≥ 1. v_max never rises, and v⁰ is within the band (ACC, or ν ≤ b·ν for all-ones, which the reference asserts). So k\* = k0 > 0 and v_max·ν ≤ v⁰_max·ν ≤ b·k0 hold for every trial with k\* = k0. ∎

**Theorem S2 (safety test).** Let v be the state when validator i is visited, so k\*(v) = k0. Let v′ be v with v_i replaced by t, 0 ≤ t ≤ v_i. Put C = k0 − 1 − t and F_i(C) = max{w(R) : i ∉ R, v(R) ≤ C}. Then

k\*(v′) = k0  ⇔  C < 0  or  w_i + F_i(C) < q.

*Proof.* A qualifying S with i ∉ S has v′(S) = v(S) ≥ k0. So k\*(v′) < k0 iff some qualifying S ∋ i has v′(S) ≤ k0 − 1. Write S = {i} ∪ R with i ∉ R. The condition becomes t + v(R) ≤ k0 − 1 and w_i + w(R) ≥ q, i.e. v(R) ≤ C and w(R) ≥ q − w_i. If C < 0, no R exists (v(R) ≥ 0). Otherwise such an R exists iff the largest w(R) subject to v(R) ≤ C, namely F_i(C), is at least q − w_i. Combined with k\*(v′) ≤ k\*(v) = k0 (monotonicity), this gives the claim. ∎

**Lemma S3 (the loop's endpoint).** Let safe(t) be the right-hand side of Theorem S2. safe is nondecreasing in t, because F_i is nondecreasing in C and C falls as t rises. safe(v_i) holds, since v itself has k\* = k0 (for t = v_i, v′ = v). While validator i is being decremented, no other coordinate changes, so F_i is fixed. The loop at value x tries x − 1, which is accepted iff safe(x − 1) (Lemma S1, Theorem S2), and stops at 0 or at the first failure. So it ends at exactly t\* = min{t ∈ [0, v_i] : safe(t)}. The implementation finds t\* by binary search on [0, v_i], using ⌈log₂(v_i + 1)⌉ evaluations of safe, and sets v_i = t\* directly. The trial count of the reference loop is (v_i − t\*) + [t\* > 0], and it is recorded as `trim_reference_trials`. The tests check that it equals the count from actually running the loop.

**Lemma S4 (prefix/suffix decomposition).** Let L[a] = max{w(R₁) : R₁ ⊆ {validators at positions < p}, v(R₁) ≤ a}, using their current (final) values. Let R_i[b] = max{w(R₂) : R₂ ⊆ {positions > p}, v(R₂) ≤ b}, using their current values, which are still the values before the trim, since those validators have not been visited. Then F_i(C) = max_{0≤a≤C} (L[a] + R_i[C − a]).
*Proof.* Every R ∌ i splits uniquely into R₁ (prefix part) and R₂ (suffix part). If v(R) ≤ C, take a = v(R₁): then w(R₁) ≤ L[a] and w(R₂) ≤ R_i[C − a], so F_i(C) ≤ max. Conversely, for any a, sets attaining L[a] and R_i[C − a] are disjoint, and their union has cost ≤ C, so max ≤ F_i(C). ∎

Only C ≤ k0 − 1 is needed, so both tables cover budgets 0..k0 − 1.

**Lemma S5 (table construction, including zero-cost items).** Adding one 0/1 item of cost c and stake w_i to a "stake at cost ≤ b" table T gives T′[b] = max(T[b], T[b − c] + w_i) for b ≥ c and T′[b] = T[b] for b < c. The right-hand sides are read from the old table (the code builds a new array), so the item is used at most once. For c = 0 this is T′[b] = T[b] + w_i: every entry rises by w_i exactly once, which is the correct 0/1 update for a positive-stake validator holding no fragment. The descending-budget loop (for positive costs only) would miss it, and an in-place update would turn the knapsack into an unbounded one. An item with c > k0 − 1 changes nothing.

**Algorithm.**
- *Suffix tables:* R_{n−1} = 0; each earlier R_i is the next one with that validator added at its original value. All n + 1 tables are kept, O(n·k0) memory.
- *Prefix table:* starts at 0. After validator i receives its final value t\*, the table gains i once, with cost t\* and stake w_i. Only the current table is kept.
- *Per validator:* each validator enters the suffix tables once and the prefix table once. Each validator with v_i > 0 costs ⌈log₂(v_i + 1)⌉ max-plus combinations of O(k0) each.
- *Totals:* the trim does O(n·k0) table work plus O(n·k0·log v_max) combination work, and runs no k\* DP.

**Equivalence to the forced-inclusion endpoint.** With r_i = min{v(R) : i ∉ R, w(R) ≥ q − w_i}, safe(t) fails iff F_i(k0 − 1 − t) ≥ q − w_i iff r_i ≤ k0 − 1 − t. So t\* = max(0, k0 − r_i), or 0 when no such R exists. `shave="direct"` computes r_i with one bounded DP per validator. It is kept only as a cross-check, and the tests confirm that both give the same endpoint for every validator.

**Optional tight-set cache** (`tight="seed"` or `True`; off by default). A qualifying S with v(S) = k0 that contains i makes i unshavable, and S stays tight while only non-members change. Members can therefore be skipped. With the prefix/suffix test, `tight="seed"` (only the winner's own minimum set) saves about 2% (§7.4), and `tight=True` costs more than it saves. The cache is off by default, so the production trim is exactly the method proved above, with no second mechanism.

### 4.6 Fallbacks

A `caps` list that is not 1, 2, …, M, parameters outside 0 < θ < 1 or band > 0, W ≤ 0, or non-integer or negative stakes are all delegated to `allocate_reference.procedure` unchanged. The CLI and the output format are unchanged, except that `seconds` is now measured with `perf_counter`.

## 5. Implementation notes

- `allocate.py`: `breakpoints`, `procedure` (cap recursion, binary search, witness guards), `trim_fast` (§4.5), and `trim_reference` (the original loop plus counters and a trace hook; the tests check that it gives the same result as `allocate_reference.trim`). `procedure(..., stats=dict, opts=dict, python=bool)` exposes the counters and the ablation switches (`bisect`, `bounded`, `witness`, `shave` ∈ {split, direct, reference}, `tight`, `check`). `check=True` re-verifies every witness and tight set and runs the full `Oracle.kstar` after every validator of the trim. These checks run only in the tests, and their DP count is reported separately (`trim_check_kstar`).
- `oracle.py`: `TicketOracle` added; `Oracle`, `nu`, `seed_sets` are untouched.
- `allocate_reference.py`, `oracle_reference.py`: byte-identical copies of the supplied `allocate.py` and `oracle.py`.
- Found by the new tests and fixed: `TicketOracle._np` indexed an empty array when no validator had a cost in 1..U. It raised an exception rather than returning a wrong result, and none of the 64 settings reach it.

## 6. Test evidence

Plain scripts, with no pytest needed: `python3 tests/run_all.py [--slow]`. Each test runs on both backends when numpy is installed. Counts below are from `TESTS_SCALE=5` (logs in `results/`). The numpy-interpreter run covers both backends, and the system `python3` run (no numpy) covers the pure-Python path again.

| test | what it checks | size (numpy interpreter + pure-Python interpreter) | result |
|---|---|---|---|
| `test_oracle.py` | `TicketOracle.kstar_upto`, `violating`, `forced_cost` against `Oracle.kstar` and subset enumeration; witnesses qualify and have the claimed cost; every "k\* > U" / "no violation" claim is true; stakes above 2^62, zeros, ties; `Oracle`/`nu`/`seed_sets` source-identical to the supplied code | 9,000 instances; 44,344 `kstar_upto`, 95,530 `violating`, 136,714 `forced_cost` checks | pass |
| `test_shaving.py` | exhaustive on small instances (n ≤ 9; ties, equal stakes, zero stakes, positive stake with zero fragments, w_i ≥ q, many minimum qualifying sets, 9 hand-made cases): every prefix table L and suffix table R_i entry used by `trim_fast` vs enumeration; the safety test for every validator and every t vs k\* by enumeration; each endpoint vs max(0, k0 − r_i); the state after every validator vs the reference loop, for shave split/direct × tight False/seed/True × check on/off; the reference loop's final vector equals `allocate_reference.trim`; trial counts equal; split runs no DP | 6,027 instances, 72,324 trajectories, 1,153,308 table entries, 449,196 safety tests, 141,000 endpoints | pass |
| `test_procedure.py` | random end-to-end instances (n ≤ 16, plus artifact-like n = 20–40): complete result dict vs `allocate_reference.procedure`, both backends, default options plus random combinations of every switch; per-cap candidates, winner and pre-trim vector captured from the untouched reference by spies; custom caps (consecutive prefixes and non-consecutive fallbacks) | 2,900 instances, 43,500 procedure runs, 435,585 per-cap candidates compared (8,340 runs via the fallback) | pass |
| `test_artifact.py` (`--slow`) | all 64 settings, live reference run: every result field, the paired recovery and protocol costs, all per-cap candidates, the winner and pre-trim vector, and the state after every validator of the trim (reference loop with exact `Oracle.kstar` vs `trim_fast`, split/direct × tight False/seed/True) | numpy interpreter: 64 settings × 2 backends, 754 candidates, 768 trajectories, 56,640 per-validator states; pure-Python interpreter: 64 settings, 384 trajectories, 28,320 states | pass |

Intermediate-state equality: in every trajectory above, the allocation after each validator's turn is identical to the reference loop's. The live sweep alone compares 84,960 per-validator states on the artifact's own networks, and none differ.

**Mutation check.** 15 plausible bugs were planted one at a time in a copy of the code, and every one was caught by at least one fast test (at 0.3× scale). They were: `<` → `≤` in the safety test; a zero-cost item skipped or added twice; the prefix table never updated; the wrong suffix cost; the endpoint off by one; the suffix including i itself; floor instead of ceiling for K_m; coarse breakpoint keys; witness expiry off by one; a lost inherited candidate; free stake ignored in either oracle backend; the trim tie order reversed. See `results/mutation_check.txt`.

**Artifact commands.** `python3 verify.py`: OK, all 294 records re-verified (exit status 0), same as the baseline. `allocate.py --check --band 11/10 --bound 4 2` and `--check --band 1 --bound 4`: every row reproduces, with numpy and without.

## 7. Timings

### 7.1 In-process, reference vs optimized

| workload | backend | reference median | optimized median | IQR | min | reps | speedup |
|---|---|---|---|---|---|---|---|
| A: Monad, eight settings | numpy | 34.8 s | 36.5 ms | 0.10 ms | 36.2 ms | 30 | 956× |
| A: Monad, eight settings | pure Python | 299.9 s | 199 ms | 5.37 ms | 194 ms | 30 | 1506× |
| B: Monad MiniCast pair (θ 2/3 + 1/3, band 11/10, 4n) | numpy | 14.8 s | 15.2 ms | 0.05 ms | 15.2 ms | 200 | 974× |
| B: Monad MiniCast pair (θ 2/3 + 1/3, band 11/10, 4n) | pure Python | 140.0 s | 103 ms | 3.65 ms | 98.6 ms | 200 | 1365× |
| C: B's main code (θ = 2/3) | numpy | 2718 ms | 4.46 ms | 0.02 ms | 4.43 ms | 200 | 609× |
| C: B's main code (θ = 2/3) | pure Python | 22.2 s | 52.0 ms | 0.76 ms | 51.2 ms | 200 | 426× |
| C: B's recovery code (θ = 1/3) | numpy | 12.1 s | 10.4 ms | 0.05 ms | 10.4 ms | 200 | 1166× |
| C: B's recovery code (θ = 1/3) | pure Python | 118.3 s | 51.1 ms | 2.79 ms | 47.9 ms | 200 | 2317× |
| D: all 64 settings | numpy | 46.6 s | 171 ms | 0.45 ms | 169 ms | 30 | 273× |
| D: all 64 settings | pure Python | 338.2 s | 449 ms | 2.19 ms | 447 ms | 30 | 753× |

The slowest single setting with numpy is Kava 1/3 11/10 4n at 15.1 ms; with pure Python it is Monad 2/3 11/10 4n at 52.9 ms. All 64 per-setting medians are in `results/timings.json`.

### 7.2 Shaving only

Both loops trim the same pre-trim vector, the reference's winner. "Reference" is the original loop with one exact `Oracle.kstar` per trial, memoized as in the reference. "Optimized" is `trim_fast` with the default options.

| allocation | n | k0 | reference (numpy oracle) | optimized, numpy | optimized, pure Python | speedup (numpy) |
|---|---|---|---|---|---|---|
| Monad θ = 2/3, band 11/10, 4n | 200 | 257 | 110 ms | 1.17 ms (IQR 0.01 ms; min 1.16 ms; 300 reps) | 9.07 ms | 94× |
| Monad θ = 1/3, band 11/10, 4n | 200 | 147 | 129 ms | 1.25 ms (IQR 0.01 ms; min 1.24 ms; 300 reps) | 5.88 ms | 103× |
| the MiniCast pair | | | 240 ms | 2.39 ms (IQR 0.01 ms; min 2.38 ms; 300 reps) | 14.9 ms | 100× |
| sum over the 64 settings | | | 1558 ms | 26.1 ms | 70.7 ms | 60× |

With the pure-Python reference oracle, the reference trim takes 997 ms (main), 1754 ms (recovery) and 9758 ms (all 64 settings).

Shaving counters for B (main / recovery): 200 / 200 validators processed; 200 / 201 fragment trials the reference performs; 200 / 200 suffix-table and 200 / 200 prefix-table item updates; 286 / 398 max-plus evaluations; 0 / 1 fragments removed; **0 k\* DPs** in both. The Monad winners (cap 3, V = 466, and cap 7, V = 786) are already almost minimal: every validator's first trial fails except one in the recovery code. Over all 64 settings the trim removes 213 fragments (§8).

### 7.3 Fresh process: `allocate.py Monad --theta 2/3 --band 11/10 --bound 4`

This is wall-clock time for the whole command (it computes the main code and its recovery), 30 runs each (reference: 3).

| command | numpy interpreter | pure-Python interpreter |
|---|---|---|
| `python -c pass` | 7.12 ms (IQR 0.04 ms; min 7.07 ms; 30 reps) | 7.71 ms (IQR 0.03 ms; min 7.67 ms; 30 reps) |
| `python -c "import numpy"` | 45.5 ms (IQR 0.19 ms; min 45.2 ms; 30 reps) | – |
| `python -c "import allocate"` | 48.0 ms (IQR 0.38 ms; min 47.6 ms; 30 reps) | 14.5 ms (IQR 0.08 ms; min 14.4 ms; 30 reps) |
| optimized `allocate.py` (workload B) | 68.6 ms (IQR 0.37 ms; min 68.3 ms; 30 reps) | 116 ms (IQR 0.77 ms; min 115 ms; 30 reps) |
| reference `allocate_reference.py` (workload B) | 14.9 s (IQR 198 ms; min 14.8 s; 3 reps) | 137.5 s (IQR 2981 ms; min 136.2 s; 3 reps) |

With numpy, start-up and imports take 48.0 ms of the 68.6 ms command, most of it `import numpy`. The computation itself is about 15.2 ms (§7.1). Without numpy, start-up is about 14.5 ms, and the pure-Python computation (103 ms) dominates.

### 7.4 Attribution (cumulative switches, numpy)

Each row adds one mechanism to the one above. "trim DPs" counts full k\* DPs in the trim.

| configuration | B median | D median | D: probes | D: decision DPs | D: full k\* DPs (scan + trim) | D: max-plus evals | D: trim time |
|---|---|---|---|---|---|---|---|
| 0 reference (`allocate_reference.py`) | 14.8 s | 46.6 s | – | – | 132,370 | – | 1558 ms |
| 1 prefix skip (cap recursion) only | 15.0 s | 46.1 s | 127,714 | 0 | 132,310 | 0 | 1572 ms |
| 2 + suffix bisection | 513 ms | 3004 ms | 5,284 | 0 | 9,879 | 0 | 1569 ms |
| 3 + bounded decision DP | 305 ms | 2076 ms | 5,284 | 5,284 | 4,724 | 0 | 1596 ms |
| 4 + prefix/suffix shaving (default shave) | 61.3 ms | 503 ms | 5,284 | 5,284 | 0 | 5,982 | 27.6 ms |
| 5 + witness guards (= production default) | 15.2 ms | 171 ms | 1,456 | 1,456 | 0 | 5,982 | 27.5 ms |
| alt: 5 with shave=direct (one forced-inclusion DP per validator) | 43.5 ms | 364 ms | 1,456 | 1,456 | 0 | 0 | 220 ms |
| alt: 5 with tight='seed' | 14.9 ms | 169 ms | 1,456 | 1,456 | 0 | 4,101 | 24.5 ms |
| alt: 5 with tight=True | 23.0 ms | 225 ms | 1,456 | 1,456 | 0 | 3,901 | 81.2 ms |

"alt" rows vary one switch of the production configuration (row 5). `shave=direct` runs one bounded forced-inclusion DP per validator (4,447 DPs over D). The tight-set cache skips validators without changing the result. `tight='seed'` is about 2% faster than the default; `tight=True` is slower, because recovering each tight set from the tables costs more than the evaluations it saves.

Row 1 is no faster than the reference. The states it skips are the prefixes shared with cap m−1, which the reference's memo already answers without a DP (132,310 vs 132,370 full DPs), so skipping them saves only loop iterations. The prefix skip matters because it makes the binary search in row 2 valid.

## 8. DP and call counts (64-setting sweep)

| quantity | reference | optimized |
|---|---|---|
| scan states the reference examines | 278,932 | 151,218 lie in prefixes shared with cap m−1 (skipped); the searched suffixes span 138,917 states up to T_m, of which only the probes below are evaluated |
| caps: inherited / empty suffix / searched | | 51 / 371 / 827 (of 1249) |
| scan: full k\* DPs (distinct states, O(n·V) each) | 127,774 | 0 |
| scan: probes / bounded decision DPs (O(n·K_m) each) | | 1,456 / 1,456 |
| scan: states skipped by witness guards | | 121,900 |
| trim: fragment trials | 4,660 | (same trials, resolved without a DP) |
| trim: full k\* DPs | 4,596 | 0 |
| trim: validators processed / fragments removed | 4,720 / 213 | same |
| trim: suffix / prefix table item updates | | 4,720 / 4,720 |
| trim: max-plus evaluations (O(k0) each) | | 5,982 |
| **total DPs** | **132,370** full | **1,456** bounded, **0** full |

The reference counts come from a counting wrapper around `Oracle.kstar`, split into scan and trim by a wrapper around `allocate_reference.trim`. The reference memoizes by state, so each call is one distinct state. There are 4,660 fragment trials in the trim but 4,596 DPs, because a trial state can repeat an earlier one (a failed decrement restores a state already evaluated, and the first trial's parent is the winner, which is cached from the scan).

## 9. Relation to the prefix/suffix proposal

The latest instructions asked for the trim to be redirected to prefix/suffix DP reuse. The code from the previous session (`shave="split"`) already used the same tables, built the same way: suffix tables over the unvisited validators' original values, built once backwards; a prefix table that grows by each validator's final value; budgets 0..k0 − 1; zero-cost items added once; the same max-plus combination. It phrased each step as "find the least r with F_i(r) ≥ q − w_i, then jump to max(0, k0 − r)". By §4.5 that is the same number as the least safe t. This session rewrote the step in the specified form: an explicit safe(t) test and a binary search for the least safe t. It also added the requested counters, the per-validator trace and the debug k\* assertions. It kept only the current prefix table unless the tight cache needs all of them, and turned the tight cache off by default. The per-validator DP formulation (`shave="direct"`) is kept only as a cross-check and is not the production path.

## 10. Remaining bottlenecks

A profile of workload B with numpy (15.3 ms per pair, median of 50; shares from cProfile cumulative times over 50 pairs, approximate because profiling inflates small calls):

| part | share of B |
|---|---|
| probe DPs (`TicketOracle.min_cost`) | 27% |
| witness expiry (cumulative sums over suffix events) | 26% |
| breakpoint list (exact keys + sort) | 14% |
| trim (`trim_fast`: tables + max-plus) | 15% |
| `state()` construction (bincount) | 1% |
| everything else (setup, candidates, Fractions, protocol) | 17% |

No single cost dominates. What remains is spread across small operations: numpy calls on arrays of a few hundred entries, Fraction arithmetic in the candidate comparison, and list building. The two large-stake networks (dYdX, Injective) run on Python integers even with numpy, but they are small (n = 31 and 50). The pure-Python backend is 6.7× slower than numpy on B and 2.6× slower on D, mainly in the loops that numpy vectorizes (the DPs, the table updates and the cumulative sums).

Per the stopping rule, no further optimization was attempted. Obvious next steps would be a C kernel for the bounded DP (with `__int128` for the large-stake networks), or a cheaper breakpoint sort (a float sort with an exact fix-up of near-ties, instead of sorting big-integer keys). Each would save a few milliseconds at most on B.

## 11. Is millisecond-scale allocation achieved?

Yes. In-process, the ordinary two-code MiniCast allocation for Monad takes 15.2 ms with numpy (103 ms without), against 14.8 s for the reference (974×). A fresh command-line run is 68.6 ms with numpy (48.0 ms of it start-up and `import numpy`) and 116 ms without. Workload A (Monad's eight settings) takes 36.5 ms against 34.8 s, and the whole 64-setting sweep takes 171 ms against 46.6 s. This is comfortably below the one-second target, and in the tens of milliseconds, with every output identical to the reference. These are measured medians, not best cases. Minima and quartiles are in §7 and `results/timings.json`.

## 12. Deliverables

In the artifact (and in `results/optimization.patch`, a `git diff` against the supplied files):

- `allocate.py`, `oracle.py`: the optimized code. `allocate_reference.py` and `oracle_reference.py` are the supplied originals, byte-identical.
- `tests/`: `run_all.py`, `test_oracle.py`, `test_shaving.py`, `test_procedure.py`, `test_artifact.py` (slow), `_util.py`.
- `benchmarks/benchmark.py`: produces the timing JSON.
- `README.md`: four rows added to the file table and one sentence on the timings. Nothing else in it, and no paper prose, is changed.
- `allocations.json`, `expected.json`, `stakes.json`, `verify.py`, `bound.py`, `solve.py`, `requirements.txt`: unchanged.

Outside the artifact (`results/`):

- `timings.json`: the numpy run and the pure-Python run, each with its environment.
- Test logs: `tests_scale5_np.txt`, `tests_scale5_py.txt`, `test_artifact_{np,py}.{txt,json}`, `mutation_check.txt`, `final_checks.txt` (`verify.py` and both `--check` commands, with and without numpy).
- `optimization.patch`.
- `bandwidth-balanced-rbc-artifact.zip` (same name as the supplied ZIP, and it unpacks into the same `bandwidth-balanced-rbc-artifact/` directory), the complete updated artifact without `.git` and `__pycache__`. Its SHA-256 is in `results/SHA256SUMS`. A file cannot contain the hash of an archive that includes it, so the hash is not repeated here.

