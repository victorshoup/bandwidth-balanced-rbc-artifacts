#!/usr/bin/env python3
"""The exact evaluator, shared by allocate.py, bound.py and solve.py.

For an allocation v (v_i fragments held by validator i) and a stake threshold
theta, a set S of validators qualifies when w(S) > theta*W.  The largest valid
reconstruction threshold is

    k*(v) = V - max{ v(T) : w(T) <= W - q },   q = floor(theta*W) + 1,

because S qualifies exactly when its complement T has w(T) <= W - q.  The inner
maximum is a 0/1 knapsack over ticket sums, solved by dynamic programming in
exact integer arithmetic.  numpy is used when present (int64, or two 45-bit
limbs when the stakes exceed 2^62); otherwise the code falls back to pure
Python integers.  The result is identical either way.

No solver is imported here.
"""
from fractions import Fraction as F

try:
    import numpy as np
except ImportError:                      # pure-Python fallback
    np = None


# --------------------------------------------------------------- exact oracle
class Oracle(object):
    """k*(v), by dynamic programming over ticket sums, exactly."""

    SHIFT = 45
    BASE = 1 << 45

    def __init__(self, w, theta):
        self.w = [int(x) for x in w]
        self.n = len(self.w)
        self.W = sum(self.w)
        self.q = (theta.numerator * self.W) // theta.denominator + 1
        self.cap = self.W - self.q
        self.big = self.W >= (1 << 62)
        if np is not None:
            if not self.big:
                self.wa = np.array(self.w, dtype=np.int64)
                self.INF = np.int64(1) << 62
            else:
                M = self.BASE - 1
                self.whi = np.array([x >> self.SHIFT for x in self.w],
                                    dtype=np.int64)
                self.wlo = np.array([x & M for x in self.w], dtype=np.int64)
                self.caphi = self.cap >> self.SHIFT
                self.caplo = self.cap & M
                self.INFHI = np.int64(1) << 50

    def qualifies(self, S):
        return sum(self.w[i] for i in S) >= self.q

    def _dp_py(self, v, V):
        minw = [None] * (V + 1)
        minw[0] = 0
        take = [bytearray(V + 1) for _ in range(self.n)]
        for i, (vi, wi) in enumerate(zip(v, self.w)):
            if vi <= 0 or vi > V:
                continue
            row = take[i]
            for t in range(V, vi - 1, -1):
                a = minw[t - vi]
                if a is not None and (minw[t] is None or a + wi < minw[t]):
                    minw[t] = a + wi
                    row[t] = 1
        tmax = max(t for t in range(V + 1)
                   if minw[t] is not None and minw[t] <= self.cap)
        return tmax, take

    def _dp_np_small(self, v, V):
        minw = np.full(V + 1, self.INF, dtype=np.int64)
        minw[0] = 0
        take = np.zeros((self.n, V + 1), dtype=bool)
        for i in range(self.n):
            vi = v[i]
            if vi <= 0 or vi > V:
                continue
            cand = minw[:V + 1 - vi] + self.wa[i]
            tgt = minw[vi:]
            imp = cand < tgt
            take[i, vi:] = imp
            minw[vi:] = np.where(imp, cand, tgt)
        return int(np.nonzero(minw <= self.cap)[0][-1]), take

    def _dp_np_big(self, v, V):
        M = self.BASE - 1
        hi = np.full(V + 1, self.INFHI, dtype=np.int64)
        lo = np.zeros(V + 1, dtype=np.int64)
        hi[0] = 0
        take = np.zeros((self.n, V + 1), dtype=bool)
        for i in range(self.n):
            vi = v[i]
            if vi <= 0 or vi > V:
                continue
            clo = lo[:V + 1 - vi] + self.wlo[i]
            carry = clo >> self.SHIFT
            clo = clo & M
            chi = hi[:V + 1 - vi] + self.whi[i] + carry
            thi, tlo = hi[vi:], lo[vi:]
            imp = (chi < thi) | ((chi == thi) & (clo < tlo))
            take[i, vi:] = imp
            hi[vi:] = np.where(imp, chi, thi)
            lo[vi:] = np.where(imp, clo, tlo)
        ok = np.nonzero((hi < self.caphi) |
                        ((hi == self.caphi) & (lo <= self.caplo)))[0]
        return int(ok[-1]), take

    def maxticket(self, v):
        v = [int(x) for x in v]
        V = sum(v)
        if np is None:
            tmax, take = self._dp_py(v, V)
        elif self.big:
            tmax, take = self._dp_np_big(v, V)
        else:
            tmax, take = self._dp_np_small(v, V)
        T, t = [], tmax
        for i in range(self.n - 1, -1, -1):
            if v[i] and take[i][t]:
                T.append(i)
                t -= v[i]
        return tmax, T

    def kstar(self, v):
        return sum(int(x) for x in v) - self.maxticket(v)[0]

    def violated(self, v, k):
        V = sum(int(x) for x in v)
        tmax, T = self.maxticket(v)
        if V - tmax >= k:
            return None
        Tset = set(T)
        return [i for i in range(self.n) if i not in Tset]

    def minimalise(self, S):
        S2 = sorted(S, key=lambda i: self.w[i])
        tot = sum(self.w[i] for i in S2)
        j = 0
        while j < len(S2) - 1 and tot - self.w[S2[j]] >= self.q:
            tot -= self.w[S2[j]]
            j += 1
        return sorted(S2[j:])


def nu(w, theta):
    W = sum(w)
    s = 0
    for k, x in enumerate(sorted(w, reverse=True), 1):
        s += x
        if s * theta.denominator > theta.numerator * W:
            return k
    return len(w)


# ------------------------------------------------------------------ seed rows
def seed_sets(O):
    n = O.n
    order = sorted(range(n), key=lambda i: (-O.w[i], i))
    light = order[::-1]
    out = set()

    def add(S):
        if sum(O.w[i] for i in S) >= O.q:
            out.add(tuple(O.minimalise(S)))

    for base in (order, light):                 # heaviest and lightest prefixes
        tot = 0
        for j, i in enumerate(base):
            tot += O.w[i]
            if tot >= O.q:
                add(base[:j + 1])
                break
    for base in (order, light):                 # each validator plus a completion
        for i in range(n):
            S, tot = [i], O.w[i]
            for j in base:
                if tot >= O.q:
                    break
                if j != i:
                    S.append(j)
                    tot += O.w[j]
            add(S)
    return sorted(out)
