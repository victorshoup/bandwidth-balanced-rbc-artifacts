#!/usr/bin/env python3
"""The lower bound of Table 2: the least average cost over real-valued shares.

For a network, a threshold theta and the band 11/10, with c = (11/10)/nu_theta:

    T*(c) = min  sum_i y_i
            s.t. y(S) >= 1   for every set S of stake greater than theta*W,
                 0 <= y_i <= c.

No allocation whose maximum is within the band can have a lower average: an
allocation (v, k) gives shares y = v/k that satisfy both constraints.  For
MiniCast both codes have independent allocations under their respective caps.
If T1 is the theta = 2/3 value and T2 the theta = 1/3 value, the protocol's
average-cost lower bound is T1*(1 + T2/n).  The recovery LP is computed even
when only --theta 2/3 is selected; repeated settings are cached.

Method.  Cutting planes.  The LP is solved over a growing set of qualifying sets
with an open-source LP solver (HiGHS, through scipy).  Separation uses the exact
oracle of oracle.py: the shares are scaled to integers, the knapsack
max{ y(T) : w(T) <= W - q } is solved by exact dynamic programming, and its
complement is a qualifying set by construction (checked in integers), so no cut
is ever spurious and the LP value is a valid lower bound at every round.

Tolerance.  The loop stops when the separation finds no set with share sum below
1 - 1e-7 at resolution 1/SCALE (SCALE = 200000).  It then certifies the final
shares independently: with every y_i rounded UP to a multiple of 1/SCALE the
same knapsack gives a rigorous upper bound on max y(T), hence a rigorous lower
bound 1 - delta on min_S y(S), which is printed.  The LP itself works in floating
point with HiGHS's default tolerances (1e-7).  So the printed value is the LP
optimum over the cuts found, a lower bound on T*(c) up to those tolerances,
attained by shares that meet every constraint to within delta.  The comparison
with expected.json is to three decimals.

Usage:
    python3 bound.py [NETWORK ... | all] [--theta 1/3 [2/3]] [--band 11/10]
                     [--json FILE]
Exit status 0 if every value agrees with expected.json to three decimals.
Requires numpy and scipy (see requirements.txt).
"""
import json
import os
import sys
import time
from fractions import Fraction as F

import numpy as np
from scipy.optimize import linprog

from oracle import Oracle, nu, seed_sets

HERE = os.path.dirname(os.path.abspath(__file__))
ORDER = ["Monad", "Kava", "Sui", "dYdX", "Sei", "Osmosis", "Injective", "Neutron"]
SCALE = 200000
STOP = 1e-7
TIMELIMIT = 900.0


def knap(O, vals):
    """max over T with w(T) <= W - q of sum(vals[T]), and the complement S."""
    tmax, T = O.maxticket(vals)
    Tset = set(T)
    S = [i for i in range(O.n) if i not in Tset]
    return tmax, S


def tstar(w, theta, c):
    n = len(w)
    O = Oracle(w, theta)
    cuts = [list(S) for S in seed_sets(O)]
    t0 = time.time()
    rounds = 0
    while True:
        rounds += 1
        A = np.zeros((len(cuts), n))
        for r, S in enumerate(cuts):
            A[r, S] = -1.0
        res = linprog(np.ones(n), A_ub=A, b_ub=-np.ones(len(cuts)),
                      bounds=[(0, float(c))] * n, method="highs")
        if res.status != 0:
            raise RuntimeError("LP failed: %s" % res.message)
        y = np.maximum(res.x, 0.0)
        val = float(res.fun)
        if time.time() - t0 > TIMELIMIT:
            converged = False
            break
        vi = [int(t) for t in np.floor(y * SCALE)]
        if sum(vi) == 0:
            converged = False
            break
        tmax, S = knap(O, vi)
        assert O.qualifies(S)                  # exact: the cut is genuine
        if y[S].sum() >= 1 - STOP:
            converged = True
            break
        cuts.append(S)
        S2 = O.minimalise(S)
        if len(S2) < len(S):
            cuts.append(S2)
    # certify: every y_i rounded up, so the knapsack over-estimates max y(T)
    up = [int(t) for t in np.ceil(y * SCALE)]
    tup, _ = knap(O, up)
    delta = max(0.0, 1.0 - (float(y.sum()) - tup / SCALE))
    return dict(value=val, converged=converged, rounds=rounds, cuts=len(cuts),
                delta=delta, max_share=float(y.max()), cap=float(c),
                seconds=time.time() - t0)


def main(argv):
    args = list(argv)
    thetas, bands, nets = ["1/3", "2/3"], ["11/10"], []
    jpath = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("--theta", "--band"):
            vals = []
            i += 1
            while i < len(args) and not args[i].startswith("--"):
                vals.append(args[i])
                i += 1
            if a == "--theta":
                thetas = vals
            else:
                bands = vals
            continue
        if a == "--json":
            jpath = args[i + 1]
            i += 2
            continue
        if a in ("-h", "--help"):
            print(__doc__)
            return 0
        nets.append(a)
        i += 1
    stakes = json.load(open(os.path.join(HERE, "stakes.json")))
    exp = json.load(open(os.path.join(HERE, "expected.json"))).get("bound", {})
    if not nets or nets == ["all"]:
        nets = [x for x in ORDER if x in stakes]
    bad = 0
    out = []
    computed = {}

    def evaluate(net, th, band):
        key = (net, th, band)
        if key not in computed:
            w = stakes[net]
            computed[key] = tstar(w, th, band / nu(w, th))
        return computed[key]

    print("%-9s %-9s %-6s %8s %8s %9s %8s %6s %6s %9s %9s %8s  %s" % (
        "protocol", "network", "band", "Tmain", "Trec", "bound", "expected",
        "rounds", "cuts", "delta1", "delta2", "seconds", "check"))
    for th_s in thetas:
        th = F(th_s)
        kind = "CT" if th == F(1, 3) else "MiniCast"
        for net in nets:
            w = stakes[net]
            for b_s in bands:
                t0 = time.time()
                band = F(b_s)
                r = evaluate(net, th, band)
                recovery = (evaluate(net, F(1, 3), band)
                            if kind == "MiniCast" else None)
                factor = (1.0 if recovery is None else
                          1.0 + recovery["value"] / len(w))
                b = r["value"] * factor
                e = exp.get(kind, {}).get(net) if b_s == "11/10" else None
                if e is None:
                    st = "no expected value"
                    if b_s == "11/10":          # Table 2 band: must be present
                        bad += 1
                elif abs(round(b, 3) - e) < 1e-9:
                    st = "ok"
                else:
                    st = "MISMATCH"
                    bad += 1
                if not r["converged"] or (recovery is not None and
                                          not recovery["converged"]):
                    st += " (NOT CONVERGED)"
                    bad += 1
                secs = time.time() - t0
                print("%-9s %-9s %-6s %8.4f %8s %9.4f %8s %6d %6d %9.1e %9s %8.1f  %s" % (
                    kind, net, b_s, r["value"],
                    "" if recovery is None else "%.4f" % recovery["value"], b,
                    "" if e is None else "%.3f" % e, r["rounds"], r["cuts"],
                    r["delta"], "" if recovery is None else "%.1e" % recovery["delta"],
                    secs, st), flush=True)
                out.append(dict(protocol=kind, network=net, theta=th_s, band=b_s,
                                tstar=r["value"], factor=factor, bound=b,
                                converged=(r["converged"] and (recovery is None or
                                           recovery["converged"])), rounds=r["rounds"],
                                cuts=r["cuts"], delta=r["delta"],
                                seconds=round(secs, 2)))
                if recovery is not None:
                    out[-1]["recovery"] = dict(theta="1/3", **recovery)
    if jpath:
        with open(jpath, "w") as fh:
            json.dump(out, fh)
    print("\n%s" % ("all bounds agree with expected.json" if bad == 0 else
                    "%d problem(s)" % bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
